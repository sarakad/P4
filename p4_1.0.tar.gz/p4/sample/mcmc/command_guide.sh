#you can run the following commands as a job script and on multiple cores
#first run the following command to generate the corresponding folders

mcmc -gip

#this will result in generating subdirectories named "ratio_ref" and "lambda_*". In each lambda_*/ subdirectory a lambda and a weight file are created. In the ratio_ref/ subdirectory a ratio file is created. 
#Then run the following command in each subdirectory. The input files in the parent directory are energy_relax, force_final.out, hessian.out, lat.in, str.in and str_relax.out

mpirun mcmc -r -T=400

#The output is written to each subdirectory in mcmc.log and denergy or ratio for lambda_*/ and ratio_ref/ subdirectories, respectively. 

#Finally, run the following command in the parent directory

mcmc -fvib

#The output is the fvib file. 
