//This file is part of the P4 package
#ifndef periodiclib_h
#define periodiclib_h 

//#include <gslwrap/matrix_double.h>
//#include <gslwrap/vector_double.h>
//#include <vector>
//#include "defaults.hh"
#include "xtalutil.h"
#include "linklist.h"
#include "fxvector.h"
#include "vectmac.h"
//#include "arraylist.h"
//#include "integer.h"
//using namespace gsl;


//inline double sqr(const double x) {return x*x;}
//void calc_lattice_vectors(matrix &lattice_vector, const matrix &cell_length, matrix &cell_angle);
//double* wrap_point(double *pt, double **bounds, int D);  
//matrix wrap_point(matrix &pt, matrix &cell);
void gen_relevant_periodic_image(double *pt, double **bounds, int D,Array<rVector3d> &rel_images);
void periodic_distance(const Array<rVector3d> &r1, const Array<rVector3d> &r2, const rMatrix3d &cell,Array<rVector3d> &dr);
void periodic_distance(const rVector3d &r1, const rVector3d &r2, const rMatrix3d &cell, rVector3d &dr);
void move(const Array<rVector3d> &pos_cur, Array<rVector3d> &pos_next, const double step_size, const Array<rVector3d> &direction, const rMatrix3d &cell);
//void move(const rVector3d &pos_cur, rVector3d &pos_next, const double step_size, const rVector3d &direction);

//void old_gen_relevant_image(double *pt,double **bounds,int D,std::vector<gsl::matrix> &rel_images);
#endif
