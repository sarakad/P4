//This file is part of the P4 package
#include "parse.h"
#include "p4_parse.hh"
#include "version.h"
#include "getvalue.h"
#include "xtalutil.h"
#include "findsym.h"
#include "integer.h"
//#include "vclib.hh"

bool closest_to_corr(const Array<rVector3d> &list, Array<rVector3d> &list2, const rMatrix3d &cell);
void unique(Array<rVector3d> &list, Array<int> &id);
int find(Array<int> &arr, int key);
bool is_duplicate(const Array<rVector3d> &list, const rVector3d &p); 
extern const char *helpstring;

int main(int argc, char *argv[]) {
  
  int dohelp = 0;
  const char *latticefilename="";//"hs_lat.in";
  const char *localfilename="";//"str_loc.in";
  const char *outfilename="";//"lat.in"; 
  

  AskStruct options[]={
    {"","Make augmented lattice given the high symmetry unstable lattice and a local distortion close by, embedded in ATAT " MAPS_VERSION ", by Sara Kadkhodaei",TITLEVAL,NULL},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-l","Input file defining the high-symmetry lattice (default: )",STRINGVAL,&latticefilename},
    {"-loc","Input file defining atomic position for the nearby local distortion (default: )",STRINGVAL,&localfilename},
    {"-ol","Output file defining the generated augmented lattice (default: )",STRINGVAL,&outfilename}
  };
  
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }
  
  //------------------------------------------------------------
  // read the high symmetry lattice file
  Structure lattice;  
  Array<Arrayint> site_type_list; //possible atomic type on each site
  Array<AutoString> atom_label;   //atom label
  rMatrix3d axes;   //coordinate axis
  
  ifstream file(latticefilename);
  if (!file) ERRORQUIT("Unable to open high symmetry lattice file."); 
    read_lattice_file(&lattice.cell, &lattice.atom_pos, &lattice.atom_type, &site_type_list, &atom_label, file, &axes);

  if (fabs(det(lattice.cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");
  file.close();
   
   int vac_type=-1;
   for (int i=0; i<atom_label.get_size(); i++){ 
	if(strcmp(atom_label(i),"Vac")==0 || strcmp(atom_label(i),"Va")==0){
        	vac_type = i;
                break;
        }
   }
   
   for (int i=0; i<site_type_list.get_size(); i++){
   	if (site_type_list(i).get_size() == 1){
		if (site_type_list(i)(0) == vac_type)
			ERRORQUIT("None of the high-symmetry lattice site could be unoccupied by atomic species.");
        }
   }


  {
     ofstream labelfile("atoms.out");
     for (int i=0; i<atom_label.get_size(); i++) {
       labelfile << atom_label(i) << endl;
     }
     labelfile.close();
  }
  //----------------------------------------------------------
  // read local structure file
  Structure str;
  ifstream file2(localfilename);
  if (!file2) ERRORQUIT("Unable to open the local structure file."); 
  parse_structure_file(&str.cell,&str.atom_pos,&str.atom_type,atom_label,file2,&axes);
  file2.close();
  if (fabs(det(str.cell))<zero_tolerance) ERRORQUIT("Lattice vectors of structure file are coplanar.");

  //check if the symmetry of the cell for structure is different from lattice and give warning
  if (!(is_int(fabs(det(str.cell)/det(lattice.cell)))))
    ERRORQUIT("The cell in structure should be an integer multiple of lattice file.");

  //check if the number of atoms in the local_str file is equal to the number of sites in the high symmetry lattice
  //
  if (str.atom_pos.get_size() != lattice.atom_pos.get_size())
       ERRORQUIT("The number of atoms in the local structure should be the same as the number of sites in the high-symmtery lattice.");
 
   
  //reorder atoms in their initial position to match the order in the relaxed position 
    Array<int> copy_from;
    Array<iVector3d> cellshift;
    reorder_atoms_notype(&lattice,str,&copy_from,&cellshift);
    lattice.atom_type = str.atom_type; 
    
   //error if the local_str position is not closest to its corresponding lattice site 
    if(!closest_to_corr(lattice.atom_pos,str.atom_pos,lattice.cell))
	ERRORQUIT("Large distortion with respect to the high symmetry lattice in the local distortion structure.");
   
   // check if the local structure atom position is the same as site position
   for (int k=0; k<str.atom_pos.get_size();k++){
       if (norm2(str.atom_pos[k]-lattice.atom_pos[k])<zero_tolerance){ 
       		ERRORQUIT("The local distortion positon is the same as high-symmetry lattice site position");
   	}
   }

  //check the symmetry of lattice cell
  SpaceGroup spacegroup;
  spacegroup.cell=lattice.cell;
  find_spacegroup(&spacegroup.point_op,&spacegroup.trans,lattice.cell,lattice.atom_pos,lattice.atom_type); //find_spacegroup cat get into a infinite loop // 

  if (contains_pure_translations(spacegroup.point_op,spacegroup.trans)) {
   cerr << "Warning: unit cell is not primitive." << endl;
  }
  //apply the symmetry to atom positions in the local structure
    int n = str.atom_pos.get_size();
    int nop = spacegroup.point_op.get_size();
    Array<rVector3d> aug(nop*n+n);
    Array<Arrayint> aug_site_type(nop*n+n); 
    for (int i=0; i<nop; i++){
	for (int j=0; j<n; j++){
                aug(n*i+j) = spacegroup.point_op(i)*str.atom_pos(j);
                aug_site_type(n*i+j).resize(site_type_list(copy_from(j)).get_size());
                for (int k=0; k<site_type_list(copy_from(j)).get_size(); k++){
                        aug_site_type(n*i+j)(k)= site_type_list(copy_from(j))(k); 
                }
        }
    }
    for (int j=0; j<lattice.atom_pos.get_size(); j++){ 
    	aug(nop*n+j) = lattice.atom_pos(j);
        aug_site_type(nop*n+j).resize(site_type_list(copy_from(j)).get_size());
        for (int k=0; k<site_type_list(copy_from(j)).get_size(); k++){
        	aug_site_type(nop*n+j)(k) = site_type_list(copy_from(j))(k); 
        }
    }
    
    //call unqiue for aug 
    wrap_inside_cell(&aug,aug,str.cell);   
    Array<int> id;
    unique(aug,id);
  
    Array<Arrayint> aug_site_type_unique(id.get_size());
    int index=-1;
    for (int i=0; i<aug_site_type.get_size(); i++){
	index= find(id,i); 
	if (index != -1){
           aug_site_type_unique(index).resize(aug_site_type(i).get_size());
           for (int j=0; j<aug_site_type(i).get_size(); j++){
              aug_site_type_unique(index)(j) = aug_site_type(i)(j);
           }
        }
    }
   
    // write out the augmented lattice file
    //
     ofstream outfile(outfilename);
     if (!outfile) ERRORQUIT("Please provide output file name for the augmented lattice.");
     rMatrix3d iaxes=!axes;
     write_axes(axes,outfile,0);
     rMatrix3d frac_cell=iaxes*lattice.cell;
     write_axes(frac_cell, outfile, 0);
     
    //cout<<"aug\n"<<aug<<endl; 
    for (int i=0; i<aug.get_size(); i++) {
      outfile << (iaxes*aug(i)) << " ";
      for (int j=0; j<aug_site_type_unique(i).get_size(); j++) {
        if (j!=0) {
  	outfile  << ",";
        }
        outfile << atom_label(aug_site_type_unique(i)(j));
      }
      outfile << endl;
    }

      return 0;

}
bool closest_to_corr(const Array<rVector3d> &list, Array<rVector3d> &list2, const rMatrix3d &cell){

  int n = list.get_size();
  if ( n != list2.get_size()) ERRORQUIT("The number of list points are not the same");

  double *r;
  r=(double*) malloc(sizeof(double)*3*n);
  m_copy(list,r);
  
  int *index;
  index=(int*) malloc(sizeof(int)*n);
  for (int i=0; i < n; i++) index[i] = i;

   Tree *tree;
   tree = build_kdtree(r,n,3,index,n,0);
   if (tree == NULL){
    free(index);
    free(r);
    ERRORQUIT("Query tree list cannot be built\n");
   }else{
     free(index);
     free(r);
   }
  
   return(is_in_vc(tree, list2, list, cell));
}
void unique(Array<rVector3d> &list, Array<int> &id){

 int n = list.get_size();
 bool add=true;
 LinkedList<rVector3d> unique_list;
 LinkedList<int> id_list;
 for (int i=0; i<n; i++){
        add=true;
	for(int j=i+1; j<n; j++){
  		if (norm2(list[i]-list[j])<zero_tolerance) {
                 add=false; 
                 break;
                }
        } 
        if (add) {id_list<< new int (i); unique_list<<new rVector3d(list[i]);}
 }
 LinkedList_to_Array(&list,unique_list); 
 LinkedList_to_Array(&id,id_list); 


/*
 double * r;
 r=(double*) malloc(sizeof(double)*3*n);
 m_copy(list,r);
  
 int * index;
 index=(int*) malloc(sizeof(int)*n);
 for (int i=0; i < n; i++) index[i] = i;

  Tree *tree;
  tree = build_kdtree(r,n,3,index,n,0);
  if ( tree == NULL){
    free(index);
    free(r);
    ERRORQUIT("Query tree list cannot be built\n");
  }else{
     free(index);
     free(r);
  }

  //run query
    double *closest_pts_m, *distances;
    int *closest_ind;
    
    closest_pts_m= (double*) malloc(sizeof(double)*3*n);
    distances = (double*) malloc(sizeof(double)*n);
    closest_ind = (int*) malloc(sizeof(double)*n);


    run_queries (tree->rootptr, r, n,3,closest_ind,distances,RETURN_INDEX);
    run_queries (tree->rootptr, r, n,3,closest_pts_m,distances,RETURN_POINTS);


    Array<rVector3d> clps(n);
    inv_m_copy(clps,closest_pts_m,n);
    
    for (int i=0; i<n; i++){
    cout<<"distances\t"<<distances[i]<<"\t";
    cout<<"closest_pts\t "<<closest_pts_m[i]<<endl;
    }
    
    LinkedList<int> unique_ind;
    LinkedList<double> unique_dis;
    LinkedList<rVector3d> unique_point;

    unique_dis << new double (distances[0]);
    unique_point << new rVector3d(clps[0]);
    unique_ind << new int (closest_ind[0]);
    int counter=1;
    for (int i=1; i<n; i++){
        for (int j=0; j<unique_ind.get_size(); j++){
        	if (closest_pts_m[i] == unique_ind(j)){
                    if (distances[i] - unique_dis(j) <zero_tolerance){ 
                         break;
                    }
                }
 	} 
        counter++;
        unique_ind<<new int (closest_ind[i]);
     }    
     cout<<"counter\n"<<counter<<endl; 
*/

}
bool is_duplicate(const Array<rVector3d> &list, const rVector3d &p){


 int n = list.get_size();
 
 double * r;
 r=(double*) malloc(sizeof(double)*3*n);
 m_copy(list,r);
  
 int * index;
 index=(int*) malloc(sizeof(int)*n);
 for (int i=0; i < n; i++) index[i] = i;

  Tree *tree;
  tree = build_kdtree(r,n,3,index,n,0);
  if ( tree == NULL){
    free(index);
    free(r);
    ERRORQUIT("Query tree list cannot be built\n");
  }else{
     free(index);
     free(r);
  }

  //run query
    double * point;
    point=(double*) malloc(sizeof(double)*3*1);
    m_copy(p,point);
    double *closest_pts_m, *distances;
    closest_pts_m= (double*) malloc(sizeof(double)*3*1);
    distances = (double*) malloc(sizeof(double)*1);
    run_queries (tree->rootptr, point, 1,3,closest_pts_m,distances,RETURN_POINTS);

    //cout<<"distances"<<distances[0]<<endl;
    if (distances[0]<zero_tolerance) return true;
    else return false;

}
int find(Array<int> &arr, int key)
{
  int index = -1;
  int n = arr.get_size();

    for(int i=0; i<n; i++)
    {
       if(arr[i]==key)
       {
         index=i;
         break;
       }
    }
   return index;
}

