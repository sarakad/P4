//This file is part of the P4 package
#include "periodiclib.hh"

void gen_relevant_periodic_image(double *pt,double **bounds,int D,Array<rVector3d> &rel_images){
	
	// Map pt onto the canonical unit cell, then produce the relevant
	// mirror image
	//bounds columns are the lattice vectors
        	
	int i,j;
	//double *wrapped_p;
        LinkedList<rVector3d> images_list; 
        rVector3d w_point,disp,point,center,is_lower,tmp;
        rMatrix3d cell;
        
        if (D !=3) ERRORQUIT("Real space is not 3 dimensional.");  
	//---------------This function calculate dr=r2-r1 with the P.B.C. considering minimum image convention (mic)
        //matrix cell(D,D),disp(D,1),point(D,1),center(D,1),is_lower(D,1),tmp(D,1);
        //wrap the point to the supercell
        //wrapped_p=wrap_point(pt, bounds, D);
  	//set up the original point, cell and center of the supercell gsl::vector
        for (i=0; i<D; i++) {
        	point(i)=pt[i]; 
                center(i)=0;
        	for (j=0; j<D; j++) {
    	  		cell(i,j)=bounds[i][j];
        	}
  	}
      
        w_point=wrap_inside_cell(point,cell);
        point=w_point;
        
        for (i=0; i<D; i++) {tmp = (cell.get_column(i)); center+=tmp*0.5;}
	
        // Point near lower boundary, include image on upper side
	// Point near upper boundary, include image on lower side
        for (i=0; i<D; i++) is_lower(i)=((point(i) < center(i)) ? 1 : -1);
	 
        //put the initial point in list of relevant points
        images_list.delete_all();
        images_list << new rVector3d(point);	
      
        //translate by one lattice vector 
        tmp=point+is_lower(0)*cell.get_column(0);
	images_list<< new rVector3d(tmp);
        tmp=point+is_lower(1)*cell.get_column(1);
        images_list<< new rVector3d(tmp);
        tmp=point+is_lower(2)*cell.get_column(2);
        images_list<< new rVector3d(tmp); 
	
        //translate by two lattice vector
	tmp=point+is_lower(0)*cell.get_column(0)+is_lower(1)*cell.get_column(1);;
        images_list<< new rVector3d(tmp);
        tmp=point+is_lower(1)*cell.get_column(1)+is_lower(2)*cell.get_column(2);
        images_list<< new rVector3d(tmp);
        tmp=point+is_lower(0)*cell.get_column(0)+is_lower(2)*cell.get_column(2);        	
	images_list<< new rVector3d(tmp);
  
       //translate by three lattice vector
       tmp=point+is_lower(0)*cell.get_column(0)+is_lower(1)*cell.get_column(1)+\
	is_lower(2)*cell.get_column(2);
       images_list<< new rVector3d(tmp);
      
       //maybe need to resize rel_images
       LinkedList_to_Array(&rel_images,images_list); 
}
void periodic_distance(const rVector3d &r1, const rVector3d &r2, const rMatrix3d &cell, rVector3d &dr)
{
//-----------This function calculate dr=r1-r2 with the P.B.C. considering minimum image convention (mic) for one atom

   rVector3d center, diff, is, disp, tmp;
   for (int i=0; i<3; i++) {tmp = (cell.get_column(i)); center+=tmp*0.5;}
   diff =  r1 - r2;
   for (int j=0; j<3; j++) is(j)=((diff(j) > center(j)) ? 1 : 0);
   for (int j=0; j<3; j++) diff -= is(j)*cell.get_column(j);
   for (int j=0; j<3; j++) is(j)=((diff(j) < -center(j)) ? 1 : 0);
   for (int j=0; j<3; j++) diff += is(j)*cell.get_column(j);

   dr = diff; 

}
void periodic_distance(const Array<rVector3d> &r1, const Array<rVector3d> &r2, const rMatrix3d &cell,Array<rVector3d> &dr){

//-----------This function calculate dr=r1-r2 with the P.B.C. considering minimum image convention (mic)
   if (r1.get_size() != r2.get_size()) ERRORQUIT("Size mismatch in periodic distance calculation."); 
   int num = r1.get_size();
  
   LinkedList<rVector3d> dr_list; 
   rVector3d center, diff, is, disp, tmp;
   
   for (int i=0; i<3; i++) {tmp = (cell.get_column(i)); center+=tmp*0.5;}
   for (int i=0; i<num; i++) {
   	diff =  r1(i) - r2(i);
        for (int j=0; j<3; j++) is(j)=((diff(j) > center(j)) ? 1 : 0);
        for (int j=0; j<3; j++) diff -= is(j)*cell.get_column(j);
        for (int j=0; j<3; j++) is(j)=((diff(j) < -center(j)) ? 1 : 0);
        for (int j=0; j<3; j++) diff += is(j)*cell.get_column(j); 
        dr_list << new rVector3d(diff);
   }
   dr.resize(num);
   LinkedList_to_Array(&dr,dr_list);
}
void move(const Array<rVector3d> &pos_cur, Array<rVector3d> &pos_next, const double step_size, const Array<rVector3d> &direction,const rMatrix3d &cell)
{
 if (pos_cur.get_size() != direction.get_size())ERRORQUIT("Size mismatch between move direction and position");
 int natom = pos_cur.get_size();
 pos_next.resize(natom);
 
 rVector3d dr;// = (0.0 , 0.0, 0.0);
 
 for (int i=0; i<natom; i++){
    dr = step_size*direction(i); 
    pos_next(i) = pos_cur(i) + dr;
 }
 
 wrap_inside_cell(&pos_next,pos_next,cell);
 
}
/*
matrix periodic_distance( const matrix &r1, const matrix &r2, const matrix &cell){
	
	//---------------This function calculate dr=r2-r1 with the P.B.C. considering minimum image convention (mic)
	matrix dr;
        matrix center,diff,is,disp;
        if (r1.get_rows() == r2.get_rows() && r1.get_cols() == r2.get_cols() && cell.get_rows() == cell.get_cols() && cell.get_rows() == r1.get_cols()){
        	int num = r1.get_rows() ;
                int D = r1.get_cols();
                dr.set_dimensions(num,D);
                center.set_dimensions(1,D);
                diff.set_dimensions(1,D);
                disp.set_dimensions(1,D);
                is.set_dimensions(1,D);
                
                for (int i=0; i<D; i++) center+=cell.get_row(i)/2;
                for (int i=0; i<num; i++) {
                    diff =  r2.get_row(i) - r1.get_row(i);
                    
                    is = ( diff > center );
		    for (int j=0; j<D; j++) diff -= is(0,j)*cell.get_row(j);
		    is = ( diff < (-1*center) );
   		    for (int j=0; j<D; j++) diff += is(0,j)*cell.get_row(j); 
                    
		    dr.set_row( i , diff);
//                     for (int j=0; j<D; j++){
//			if (p(0,i) > (highl-lowl)/2) {dr[i]=dr[i]-(highl-lowl);}
//			if (p(0,i) < -(highl-lowl)/2) {dr[i]=dr[i]+(highl-lowl);}
//		
//		}
		}
	
	}else{
        	std::cerr<<"In geometrylib:periodic_distance: Matrix size mismatch\n";
	}
        return dr;

}
*/
/*
void old_gen_relevant_image(double *pt,double **bounds,int D,std::vector<gsl::matrix> &rel_images){
	
	// Map pt onto the canonical unit cell, then produce the relevant
	// mirror image
        	
	int i,j;
	double *wrapped_p;
        //Point p;
        double disp,distance_upper_bound;
        std::vector<matrix> extra_p;
        
        matrix point(D,1),tmp(D,1);
	
        //wrap the point to the supercell
        wrapped_p=wrap_point(pt, bounds, D);
  	//set up the original point, cell and center of the supercell gsl::vector
        for (i=0; i<D; i++) {
        	point(i,0)=wrapped_p[i];
  	}
	 
        //put the initial point in list of relevant points
	rel_images.erase(rel_images.begin(),rel_images.end());
	rel_images.push_back(point);
	for (i=0; i<D; i++) {
                distance_upper_bound=bounds[i][i]/2;
		if ((bounds)[i][i]>0.0) {
			disp=bounds[i][i];
			if (distance_upper_bound>1.0e10) {
				
				extra_p.erase(extra_p.begin(),extra_p.end());
				
				for (j=0; j<rel_images.size(); j++) {
					tmp=rel_images[j];						
					tmp=rel_images[j]+disp;
					extra_p.push_back(tmp);
				}
				
				
				for (j=0; j<rel_images.size(); j++) {
					tmp=rel_images[j];						
					tmp=rel_images[j]-disp;
					extra_p.push_back(tmp);
				}
				
				rel_images.insert(rel_images.end(),extra_p.begin(),extra_p.end());
				
			}else {
				extra_p.erase(extra_p.begin(),extra_p.end());
				// Point near lower boundary, include image on upper side
				if (fabs(wrapped_p[i])<distance_upper_bound) {
					for (j=0; j<rel_images.size(); j++) {
						tmp=rel_images[j];						
						tmp=rel_images[j]+disp;
						extra_p.push_back(tmp);
					}
					//
				}
				// Point near upper boundary, include image on lower side
				if (fabs(bounds[i][i]-wrapped_p[i])<distance_upper_bound) {
					for (j=0; j<rel_images.size(); j++) {
						tmp=rel_images[j];						
						tmp=rel_images[j]-disp;
						extra_p.push_back(tmp);
					}
				}
				
				rel_images.insert(rel_images.end(),extra_p.begin(),extra_p.end());
			}
			
		}
	}
	
	
}
*/
