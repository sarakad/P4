//This file is part of the P4 package
#include "array.h"
void update_hessian(Array2d<Real> &hess_new, const Array2d<Real> &hess_old, const Array<Real> &dgrad, const Array<Real> &displacement);
void murtagh_update(Array2d<Real> &correction, const Array<Real> &xi, const Array<Real> &dgrad, const Array<Real> &displacement);
void powell_update(Array2d<Real> &correction,const Array<Real> &xi, const Array<Real> &dgrad, const Array<Real> &displacement, Real &phi);
