//This file is part of the P4 package
#include "kdtree_common.hh"
#include "version.h"
#include "periodiclib.hh"
#include "p4_parse.hh"
#include "mpi.h"

extern Real kb;
extern Real h;
extern Real curve_val;
extern ofstream mcmclog;
extern ofstream mcmctest;
extern unsigned int maxiter;
extern unsigned int burnIn_steps;
extern unsigned int gap_steps;
extern unsigned int trial_steps;
extern Real etol;
extern Real step_size;

class MCParam{
public:
	unsigned int maxiter;
	unsigned int burnIn_steps;
	unsigned int gap_steps;
	unsigned int trial_steps;
	Real etol;
	Real step_size;
public:
	MCParam():maxiter(pow(10.0,9)), burnIn_steps(10000), gap_steps(10000),trial_steps(5000000),etol(0.001),step_size(0.01){}
	MCParam(const unsigned int _b, const unsigned int _g ){
		burnIn_steps = _b;
		gap_steps = _g;
  		trial_steps=500*gap_steps;
 		maxiter=1*pow(10.0,9);
		etol=0.001;
		step_size=0.01;
	}
};

class MCMC{  //define a Monte Carlo Markov Chain class
public:
  Real T;                    //defiens the temperature at which the Monte Carlo Markov Chain is conducted
  rMatrix3d cell;            //the supercell or MC simulation box
  Array<rVector3d> pos_cur;  //current position of mcmc
  Array<rVector3d> pos_next; //next position of mcmc
  Real e_cur;                //current energy
  Real e_next;               //next energy
  
  MCMC(void){}
  MCMC(const Array<rVector3d> &_cur_pos, const rMatrix3d _cell, const Real _T) {
     T=_T;
     pos_cur=_cur_pos; 
     cell=_cell;
     pos_next.resize(pos_cur.get_size());
     pos_next = pos_cur;  
  }
  void perturb(void); 
  int accept(void); 
  void print_status();
};
class MCMCHarmonic: public MCMC{
public:
  //MCParam param;
  Array<Real> mass;
  Array<Real> force;
  Array2d<Real> hess;
  Real c_val;
  Array<rVector3d> pos0_real;
  Array<rVector3d> pos0_ref;
  Real lambda;
  Real accum;
  int accum_count;
  Real ave_val;
  Tree *tree;
   
  MCMCHarmonic(const Array<rVector3d> &_cur_pos, const rMatrix3d _cell, const Real _T){
     T=_T;
     pos_cur=_cur_pos;
     cell=_cell;
     pos_next.resize(pos_cur.get_size());
     pos_next = pos_cur;  
  }
  void init(const char* forcefilename, const char* hessfilename, const Array<rVector3d> &rel_pos, const Array<rVector3d> &init_pos, const Array<Real> &masses, const Real _lambda);
  void init_tree(Tree *ptree){tree = ptree;}
  void burnIn();
  void run(const unsigned int steps); //same as burIn but add to accum
  int estimate_steps(void);//run and estimate the number of steps need 
  void test(void); //run test to estimate parameters
  Real calc_energy(const Array<rVector3d> &pos);
};
class MCMCRef: public MCMC{
public:
  Real c_val;
  Array<rVector3d> pos0_ref;
  int accum;
  int accum_count;
  Real ave_val;
  Tree *tree;
   
  MCMCRef(const Array<rVector3d> &_cur_pos, const rMatrix3d _cell, const Real _T){
     T=_T;
     pos_cur=_cur_pos;
     cell=_cell;
     pos_next.resize(pos_cur.get_size());
     pos_next = pos_cur;
  }
  void init(const Array<rVector3d> &init_pos);
  void init_tree(Tree *ptree){tree = ptree;}
  void burnIn();
  void run(const unsigned int steps); 
  int estimate_steps(int vec_size);//run and estimate the number of steps needed
  Real calc_energy(const Array<rVector3d> &pos);
  
};
Real calc_energy_harmonic(const Array<rVector3d> &pos0, const Array<rVector3d> &pos,const rMatrix3d cell, const Array<Real> &mass, const Array<Real> &force, const Array2d<Real> &hess); 
Real calc_energy_harmonic(const Array<rVector3d> &pos0, const Array<rVector3d> &pos, const rMatrix3d cell, const Array<Real> &mass, const Array<Real> &force, const Array2d<Real> &eigvec, const Array<Real> &eigval);
Real calc_energy_harmonic(const Array<rVector3d> &pos0, const Array<rVector3d> &pos, const rMatrix3d cell, const Real cval);

class MCStat{
public:  
  Array<Real> input;
  Real ave;
  Real variance;
  Real std;
  Real sterr; 
  
  void view(){
    mcmclog<<"The statistical analysis of Monte Carlo sampling\n"; 
    mcmclog<< "\tSample size is:\t"<<input.get_size()<<endl;
    mcmclog<< "\tThe average value for sampling input is:\t" <<ave<< endl;
    mcmclog<< "\tVariance: \t" <<variance<<endl;
    mcmclog<< "\tStandard Deviation:\t"<<std<<endl;
    mcmclog<< "\tStatistical error :\t"<<sterr<<endl;
    mcmclog<<endl;
  }

};
Real calc_ave(const Array<Real> &input)
{
   int n = input.get_size();
   Real sum=0;
   for (int i=0; i<n; i++) sum+=input(i);
   return (sum/n); 
} 
Real calc_variance(const Array<Real> &input)
{
   int n = input.get_size();
   Real mean = calc_ave(input);
   Real tmp;
   for (int i=0; i<n; i++) tmp+=(input(i)-mean)*(input(i)-mean);
   return tmp/(n-1);
} 
Real calc_std(const Array<Real> &input)
{
   return sqrt(calc_variance(input));
}
Real calc_sterr(const Array<Real> &input)
{
   int n = input.get_size();
   Real std = calc_std(input);
   return std/sqrt(n);
} 
