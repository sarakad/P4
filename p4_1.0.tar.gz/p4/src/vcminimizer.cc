//This file is part of the P4 package
#include "vcminimizer.hh"
Real step_size=0.01;
void MotionInVC::perturb_in_vc(const AugStructure &s)
{
//--------------------------------------------------------------------------
//------------------------starting perturbation-------------------------------
	//In this function, we will perturb the current position along the negative gradient (force).
	//If the perturbed config pos_cur is out of V.C. we will only consider the forces along the boundaries of V.C. where the atoms is going out.
		
	//FACE:
	//If the atom is crossing along one face of polyhedron then by 1-time projection, the perturbation pos_next will stay in V.C.
		
	//EDGE:
	//If the atom is close to the edge of the polyhedron (intersection of 2 faces),if 2 faces are normal to each other, the projection will work in 2 steps. After geenral projection and rejection of vector that are not necessarily orthonormal, after 2 steps the rejection will not be in any of the normal vector direction.
			
	//CORNER(VERTEX):
	//If the atom is close to the corner of the polyhedron(intersection of 3 faces)    
	//same as EDGE but there is 3 different normal vectors 

 unsigned int i,j;
 int face=0, edge=0, corner=0;
 int natom = pos_cur.get_size();
 pos_next.resize(natom);
 if (3*pos_cur.get_size() != force.get_size()) ERRORQUIT("Size mismatch between force and position");
 
 if (s.atom_pos.get_size() != pos_cur.get_size()) ERRORQUIT("Some atoms are lost during perturbation in VC.");
 
 bool InVcell;
 double f_norm=0;
 Array<rVector3d> nhat1, nhat2, nhat3, nhat4; //Normal vectors to each boundary plane that an atom is crossing 
 nhat1.resize(1); nhat2.resize(1);  nhat3.resize(1); nhat4.resize(1);         //array of length 1 for one atom
 Array<rVector3d> search_dir;
 search_dir.resize(1);          //array of length 1 for one atom
 Array<rVector3d> pos_atom_cur, pos_atom_next, pos_atom_init;
 pos_atom_cur.resize(1); pos_atom_next.resize(1); pos_atom_init.resize(1); //array of length 1 for one atom
 Array<rVector3d> f_atom, fv_atom;
 f_atom.resize(1); fv_atom.resize(1);
 Array<int> crossif;
 crossif.resize(1);
 
 
 for (i=0;i<natom;i++){	
    //initialize the atom force and position
    pos_atom_init(0) = s.atom_pos(i);
    pos_atom_cur(0) = pos_cur(i);
    pos_atom_next = pos_atom_cur ;
    f_atom(0) = rVector3d(force(3*i+0),force(3*i+1),force(3*i+2));
    fv_atom = f_atom;
    
    //initialize the search direction
    if(norm(f_atom(0))<zero_tolerance) f_norm = 1;
    else f_norm = norm(f_atom(0));
    search_dir(0) = f_atom(0)/f_norm;
    
    //move atom along search direction
    move(pos_atom_cur,pos_atom_next,step_size,search_dir,s.supercell);
    InVcell = is_in_vc(s.tree,pos_atom_next,pos_atom_init,s.supercell,crossif,nhat1); 
    if(!InVcell){
      face = 1; 
      //get force rejection along the face normal and move along that 
      vectorRejection(f_atom(0),nhat1(0),fv_atom(0));
      if(norm(fv_atom(0))<zero_tolerance) f_norm = 1;
      else f_norm = norm(fv_atom(0));
      search_dir(0) = fv_atom(0)/f_norm;
      move(pos_atom_cur,pos_atom_next,step_size,search_dir,s.supercell); 
      InVcell = is_in_vc(s.tree,pos_atom_next,pos_atom_init,s.supercell,crossif,nhat2);
      if (!InVcell && norm(search_dir(0))>zero_tolerance){
          face = 0;
          edge = 1;
         //reject the force vector along two normal vectors simultaneously
         vectorRejection(f_atom(0),nhat1(0),nhat2(0),fv_atom(0)); 
         if(norm(fv_atom(0))<zero_tolerance) f_norm = 1;
         else f_norm = norm(fv_atom(0));
         search_dir(0) = fv_atom(0)/f_norm;
         //move atom along search direction
         move(pos_atom_cur,pos_atom_next,step_size,search_dir,s.supercell);
         InVcell = is_in_vc(s.tree,pos_atom_next,pos_atom_init,s.supercell,crossif,nhat3);
         if (!InVcell && norm(search_dir(0))>zero_tolerance){
              face =0; edge = 0; corner =1;

             //reject the force vector along three normal vectors simultaneously
             vectorRejection(f_atom(0),nhat1(0),nhat2(0),nhat3(0),fv_atom(0)); 
             if(norm(fv_atom(0))<zero_tolerance) f_norm = 1;
             else f_norm = norm(fv_atom(0));
             search_dir(0) = fv_atom(0)/f_norm;
             //move atom along search direction
             move(pos_atom_cur,pos_atom_next,step_size,search_dir,s.supercell);
             InVcell = is_in_vc(s.tree,pos_atom_next,pos_atom_init,s.supercell,crossif,nhat4);
             if (!InVcell) ERRORQUIT("After 3 simultaneous force rejection at the corner the configuration is not inside Voronoi cell. Some implementation must be wrong!");
         }
      }

   } //if the move lead the atom outsied of VC
   pos_next(i)=pos_atom_next(0);
   if (face) 
      cout<<"atom "<<i+1<<" encounters a face with normal vecotr of :\t" <<nhat1(0)<<endl; 
   else if (edge)
          cout<<"atom "<<i+1<<" encounters an edge with normal vecotrs of :\t" <<nhat1(0)<<"\tand\t"<<nhat2(0)<<endl;
   else if (corner)
       cout<<"atom "<<i+1<<" encounters a corner with normal vecotrs of :\t" <<nhat1(0)<<"\tand\t"<<nhat2(0)<<"\tand\t"<<nhat3(0)<<endl;
   face=0; edge=0; corner=0;

 }//end loop on atoms

//it is possible to write this function w/o the need for a loop over atoms ->reconsider vector rejection


//end function
}
extern const char *helpstring;

int main(int argc, char *argv[]) {
  // parse command line arguments or display help (see getvalue.h);
  int dohelp=0;
  const char *latticefilename="lat.in";
  const char *strfilename="str.in";
  //const char *ostrfilename="str_relax.out";
  //const char *forcefilename="force.out";
  int dummy=0;
  int quiet=0;
  int sigdig=5;
  
  AskStruct options[]={
    {"","Voronoi Cell Motion method embedded in ATAT " MAPS_VERSION ", by Sara Kadkhodaei",TITLEVAL,NULL},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-l","Input file defining the augmented lattice (default: lat.in)",STRINGVAL,&latticefilename},
    {"-is","Input file defining the structure (default: str.in)",STRINGVAL,&strfilename},
    {"-ss","Magnitude for step size in gradient descent algorithm (default: 1e-2)",REALVAL,&step_size},
    {"-d","Use all default values",BOOLVAL,&dummy}
  };//{"-q","Quiet mode (do not print status to stderr)",BOOLVAL,&quiet},
  
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }
 
  zero_tolerance = 0.01 * step_size;
  //read str.in as the initial position of atoms 
  AugStructure str0;
  str0.init(latticefilename,strfilename);
  
  //read str_cur.out as the currect geometry of the atoms, which is generated by this code 
  AugStructure curstr;
  curstr.init(latticefilename,"str_cur.out");
  
  //reorder atoms to make match the order in str.in 
  Array<int> copy_from;
  Array<iVector3d> cellshift;
  //reorder_atoms_aug(&curstr,str0,&copy_from,&cellshift);
  reorder_atoms_aug(&str0,curstr,&copy_from,&cellshift);
  //cout<<"copy_from\n"<<copy_from<<endl;
  //cout<<"str0.atom_pos\n"<<str0.atom_pos<<endl;
  //cout<<"curstr.atom_pos\n"<<curstr.atom_pos<<endl;
  //cout<<"str0.atom_type\n"<<str0.atom_type<<endl;
  //cout<<"curstr.atom_type\n"<<curstr.atom_type<<endl;
  
  /*
  cout<<"str0.supercell\n"<<str0.supercell<<endl;
  cout<<"str0.atom_pos\n"<<str0.atom_pos<<endl;
  cout<<"str0.atom_type\n"<<str0.atom_type<<endl;
  cout<<"str0.super_site_pos\n"<<str0.super_site_pos<<endl;
  cout<<"str0.tree\n"<<str0.tree<<endl;
  cout<<"str0.atom_label\n"<<str0.atom_label<<endl;
  cout<<"str0.axes\n"<<str0.axes<<endl;
 
  cout<<"curstr.supercell\n"<<curstr.supercell<<endl;
  cout<<"curstr.atom_pos\n"<<curstr.atom_pos<<endl;
  cout<<"curstr.atom_type\n"<<curstr.atom_type<<endl;
  cout<<"curstr.super_site_pos\n"<<curstr.super_site_pos<<endl;
  cout<<"curstr.tree\n"<<curstr.tree<<endl;
  cout<<"curstr.atom_label\n"<<curstr.atom_label<<endl;
  cout<<"curstr.axes\n"<<curstr.axes<<endl;
*/

  int natom = curstr.atom_pos.get_size();
  if (str0.atom_pos.get_size() != natom) ERRORQUIT("The number of atoms in str.in and str.out are not the same.");
  if (norm(str0.supercell  - curstr.supercell)>zero_tolerance) ERRORQUIT("Change in supercell shape.");; 
  //check if the currect atomic position is inside the Voronoi cell
  Array<int> crossif(natom);
  Array<rVector3d> normal_vec(natom);
  
  if(!is_in_vc(str0.tree,curstr.atom_pos,str0.atom_pos,str0.supercell,crossif,normal_vec)) 
    ERRORQUIT("The strutrure is not initially inside the Voronoi cell.");
  
  //set the motionInVC object and read force.out
  MotionInVC mvc(curstr.atom_pos);
  ifstream forcefile("force_cur.out");
  if(!forcefile) ERRORQUIT("Unable to open force file");
  Array<int> copy(natom);
  for (int i=0; i<natom; i++) copy(i)=i;
  read_force(&mvc.force,forcefile,copy); 
  forcefile.close();
  //cout<<"mvc.force\n"<<mvc.force<<endl;
  
  cout<<"Start steepest descent move inside Voronoi cell\n"; 
  mvc.perturb_in_vc(str0); 
  curstr.atom_pos = mvc.pos_next;
  //mvc.pos_cur = mvc.pos_next; //subs with writing pos_next to str_cur.out
  
  curstr.write_str("str_next.out"); 
  return 0; 
}
