//This file is part of the P4 package
#include "parse.h"
#include "p4_parse.hh"
#include "version.h"
#include "getvalue.h"
#include "xtalutil.h"
#include "findsym.h"
#include "integer.h"
#include <vector>
//#include "vclib.hh"
void erase_array_from_array(Array<int> &source, Array<int> &remove)
{
  std::vector<int> myvec;
  int n1=source.get_size(), n2=remove.get_size();
  for (int i=0; i<n1; i++) myvec.push_back(source(i));
  
  for (int i=0; i<n2; i++){
  	for (int j=0; j<myvec.size(); j++){
		if(remove(i) == myvec[j]){
			myvec.erase(myvec.begin()+j);
			break;		
		}
	}
  }
  
  source.resize(myvec.size());
  for (int j=0; j<myvec.size(); j++)
  	source(j)=myvec[j];

}
// A function to randomly select k items from stream[0..n-1].
void selectKItems(Array<int> &stream, int n, int k, Array<int> &reservoir)
{
    int i;  // index for elements in stream
 
    // reservoir is the output array. Initialize it with
    // first k elements from stream[]
    reservoir.resize(k);
    for (i = 0; i < k; i++)
        reservoir[i] = stream[i];
 
    // Use a different seed value so that we don't get
    // same result each time we run this program
    //srand(time(NULL));
    rndseed(0);
 
    // Iterate from the (k+1)th element to nth element
    for (; i < n; i++)
    {
        // Pick a random index from 0 to i.
        int j = rand() % (i+1);
 
        // If the randomly  picked index is smaller than k, then replace
        // the element present at the index with new element from stream
        if (j < k)
          reservoir[j] = stream[i];
    }
 
}
int find(Array<int> &arr, int key)
{
  int index = -1;
  int n = arr.get_size();

    for(int i=0; i<n; i++)
    {
       if(arr[i]==key)
       {
         index=i;
         break;
       }
    }
   return index;
}

void find(const Array<int> &arr, int key, Array<int> &indx)
{
  LinkedList<int> index;
  
  int n = arr.get_size();
  int count = 0;
    for(int i=0; i<n; i++)
    {
       if(arr[i]==key)
       {
         index << new int (i);
         count++;
       }
    }
   indx.resize(count); 
   LinkedList_to_Array(&indx,index); 
   
}


extern const char *helpstring;

int main(int argc, char *argv[]) {
  
  int dohelp = 0;
  const char *latticefilename="lat.in";
  const char *hslatticefilename="hs_lat.in";
  const char *outfilename="str.in";
  int dummy=0;
  int seed = 0;
  Array<Real> super_arr;
  int printVac = 0; 
 
  AskStruct options[]={
    {"","Generate structures on the provided augmented lattice randomly, embedded in ATAT " MAPS_VERSION ", by Sara Kadkhodaei",TITLEVAL,NULL},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-laug","Input file defining the augmented lattice (default: lat.in)",STRINGVAL,&latticefilename},
    {"-lhs","Input file defining the high-symmetry unstable lattice (default: hs_lat.in)",STRINGVAL,&hslatticefilename},
    {"-ss","Supercell size for generated structure (3 integer seprated by comma)",ARRAYRVAL,&super_arr},
    {"-sd","Seed for random number generation (default: use clock)",INTVAL,&seed},
    {"-os","Output file defining the atomic position for the generated structure (default: str.in)",STRINGVAL,&outfilename},
    {"-vac","Print out vacancies in the generated structure file",BOOLVAL,&printVac}
  };
  
  
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }
 //------------------------------------------------------------
 // read the high symmetry lattice file
   Structure hs_lattice;  
   Array<Arrayint> site_type_list; //possible atomic type on each site
   Array<AutoString> atom_label;   //atom label
   rMatrix3d axes;   //coordinate axis
   
   ifstream file1(hslatticefilename);
   if (!file1) ERRORQUIT("Unable to open lattice file."); 
     read_lattice_file(&hs_lattice.cell, &hs_lattice.atom_pos, &hs_lattice.atom_type, &site_type_list, &atom_label, file1, &axes);
   file1.close();
   
   wrap_inside_cell(&hs_lattice.atom_pos,hs_lattice.atom_pos,hs_lattice.cell);
   if (fabs(det(hs_lattice.cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");

 //------------------------------------------------------------
 // read the augmented lattice file
   Structure lattice;  
   Array<Arrayint> site_type_list_redun; 
   Array<AutoString> atom_label_redun;

   ifstream file(latticefilename);
   if (!file) ERRORQUIT("Unable to open lattice file."); 
     read_lattice_file(&lattice.cell, &lattice.atom_pos, &lattice.atom_type, &site_type_list_redun, &atom_label_redun, file, &axes);
   file.close();

   if((atom_label_redun == atom_label) != 0){
	ERRORQUIT("The atom type list for the high symmetry lattice and augmented lattice are not the same.\n GUIDE: use \"auglat\" command to generate the augmented lattice from the high-symmetry lattice.");
   }
   if (fabs(det(lattice.cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");
   wrap_inside_cell(&lattice.atom_pos,lattice.atom_pos,lattice.cell);
   
   int vac_type=-1;
   for (int i=0; i<atom_label.get_size(); i++){ 
	if(strcmp(atom_label(i),"Vac")==0 || strcmp(atom_label(i),"Va")==0){
        	vac_type = i;
                break;
        }
   }
   
   for (int i=0; i<site_type_list.get_size(); i++){
   	if (site_type_list(i).get_size() == 1){
		if (site_type_list(i)(0) == vac_type)
			ERRORQUIT("None of the high-symmetry lattice site could be unoccupied.");
        }
   }


   {
      ofstream labelfile("atoms.out");
      for (int i=0; i<atom_label.get_size(); i++) {
        labelfile << atom_label(i) << endl;
      }
      labelfile.close();
   }
   
   if (norm(lattice.cell - hs_lattice.cell) >zero_tolerance)
   	ERRORQUIT("high-symmtery lattice and augmented lattice have different cell shape.");
   
   //check the symmetry of lattice cell
   SpaceGroup spacegroup;
   spacegroup.cell=lattice.cell;
   find_spacegroup(&spacegroup.point_op,&spacegroup.trans,lattice.cell,lattice.atom_pos,lattice.atom_type);               

   if (contains_pure_translations(spacegroup.point_op,spacegroup.trans)) {
       cerr << "Warning: unit cell is not primitive." << endl;
   }

   // create the supercell
   
     AugStructure str;
     AugStructure hs_str;
     
     if (super_arr.get_size() != 3) 
  	ERRORQUIT("The supercell size should be 3 integers");
     
     rVector3d tmp;
     for (int j=0;j<3;j++){
          tmp = super_arr(j)* lattice.cell.get_column(j);
     	str.supercell.set_column(j, tmp);
     }
     hs_str.supercell = str.supercell;
      
     Array<int> hs_super_site_type; 
     Array<int> super_site_type;
   
     find_all_atom_in_supercell(&hs_str.super_site_pos, &hs_super_site_type, hs_lattice.atom_pos, hs_lattice.atom_type, hs_lattice.cell, hs_str.supercell);
     find_all_atom_in_supercell(&str.super_site_pos, &super_site_type, lattice.atom_pos, lattice.atom_type, lattice.cell, str.supercell);

     int natom = hs_str.super_site_pos.get_size();
     int nsite = str.super_site_pos.get_size();
     
     
    Array<Arrayint> super_site_type_list(natom);  
    LatticePointInCellIterator l(hs_lattice.cell,hs_str.supercell);
    int index=0;
    for ( ; l; l++) {
      for (int s=0; s<hs_lattice.atom_pos.get_size(); s++) {
        super_site_type_list(index)=site_type_list(s);
        index++;
      }
    }
   
  // check constraints on concentration  
  bool constraint=false;
  Array<Real> conc_list;
  Array<int> is_conc;
  if (file_exists("conc.in")) {
    constraint=true;
    ifstream consfile("conc.in");
    read_conc(conc_list,is_conc,atom_label,consfile);
  }
  Array<int> num_of_each_species(conc_list.get_size());
  zero_array(&num_of_each_species);
  for (int i=0; i<conc_list.get_size(); i++){
	if (is_conc(i) == 1) num_of_each_species(i) = round(natom*conc_list(i));
  }
  Array<int> concind;
  find(is_conc,1,concind); 
  // find sites belonging to one group of sites
    hs_str.build_tree(hs_str.super_site_pos);
    Array<int> closest_ind;
    Array<rVector3d> closest_pts;
    find_closestpts(hs_str.tree,str.super_site_pos,str.supercell,closest_pts);
    find_closestindx(hs_str.tree,str.super_site_pos,str.supercell,closest_ind);
    
  // write out the structure file 
  // generate structure randomly given the concentration of each species (default is random concentration)
  // For each group of sites, one atom should occupy and the rests are Vac
    
     rndseed(seed);
    
     ofstream outfile(outfilename);
     rMatrix3d iaxes=!axes;
     write_axes(axes,outfile,0);
     rMatrix3d frac_cell=iaxes*str.supercell;
     write_axes(frac_cell, outfile, 0);
     
     Array<int> gind;
     int occup; 
     int species;
     if(!constraint){
         for (int i = 0; i< natom; i++){
             find(closest_ind,i,gind);
             occup = random (gind.get_size());
             for (int k = 0; k<gind.get_size(); k++){
    	     	if (k == occup){
                 	if (vac_type == -1){
                  		species = random (super_site_type_list(i).get_size());
                  	}else{
    	      			do{
                     			species = random (super_site_type_list(i).get_size());
    	        		}while(super_site_type_list(i)(species) == vac_type);
    	      		}
                    	outfile<<iaxes*str.super_site_pos(gind(k))<<" "<<atom_label(super_site_type_list(i)(species))<<endl;
    	     	}else{
                    if (printVac) outfile<<iaxes*str.super_site_pos(gind(k))<<" Vac"<<endl;
                } 
             }
         }
    }else{
    //find out which hs sites are eligible for each constrained atomic species
    Array<Arrayint> eligible_sites(concind.get_size()); 
    LinkedList<int> tmp_list;
    for (int cc=0; cc<eligible_sites.get_size(); cc++){
	tmp_list.delete_all();
        for (int ss=0; ss<natom; ss++){
		for (int tt=0; tt<super_site_type_list(ss).get_size(); tt++){
			if (super_site_type_list(ss)(tt) == concind(cc)){ 
				tmp_list << new int (ss);
				break;
			}
		}
	}
        LinkedList_to_Array(&eligible_sites(cc),tmp_list);
        if (eligible_sites(cc).get_size() < num_of_each_species(concind(cc)))
		ERRORQUIT("The number of sites that allow the atomic species are less than the specified atomic concentration in conc.in.");
    }
    //sort the id of atomic types based on their fraction 
    Array<int> sorted_num(eligible_sites.get_size());
    Array<int> id(eligible_sites.get_size());
    Array<int> type(eligible_sites.get_size());
    for (int cc=0; cc<eligible_sites.get_size(); cc++){
	sorted_num(cc) = eligible_sites(cc).get_size();
        id(cc) = (cc);
        type(cc) = concind(cc);
    }
    for (int i=0; i<sorted_num.get_size()-1; i++) {
      for (int j=i; j<sorted_num.get_size()-1; j++) {
        if (sorted_num(j)>sorted_num(j+1)) {
		swap(sorted_num(j),sorted_num(j+1));
		swap(id(j),id(j+1));
		swap(type(j),type(j+1));
	}
      }
    }
    //fill in eligible sites for each constrained atomic species
    int sum=0, ns;
    Array<int> global_eligible(natom);
    for (int i=0; i<natom; i++) global_eligible(i)=i;


    for (int cc=0; cc<concind.get_size(); cc++){
	ns = eligible_sites(id(cc)).get_size();
        LinkedList<int> source_list;
	for (int i=0; i<ns; i++){
		if(find(global_eligible,eligible_sites(id(cc))(i))!=-1){
			source_list<< new int(eligible_sites(id(cc))(i));
		}
	}
        Array<int> source;
        LinkedList_to_Array(&source,source_list);
        Array<int> reservoir(num_of_each_species(type(cc)));
        selectKItems(source, source.get_size(), num_of_each_species(type(cc)), reservoir);	
        erase_array_from_array(global_eligible,reservoir);
        sum += reservoir.get_size();
	species = type(cc);
        for (int i=0; i<reservoir.get_size(); i++){
		
             find(closest_ind,reservoir(i),gind);	
             occup = random (gind.get_size());
             for (int k = 0; k<gind.get_size(); k++){
    	     	if (k == occup){
                    outfile<<iaxes*str.super_site_pos(gind(k))<<" "<<atom_label(species)<<endl;
    	     	}else{
                    if (printVac) outfile<<iaxes*str.super_site_pos(gind(k))<<" Vac"<<endl;
                } 
             }
	
        }
     }//end loop for constrained atomic species
      //sometimes due to rounding of fraction, the num of filled is less than natom even if all atomic species are constrained. In this case fill in the rest out of the constrained species randomly
      bool from_same=false;
      Array<int> nonconc;
      if (vac_type == -1){
 	if(find(is_conc,0)==-1 && sum < natom) from_same=true;
      }else{
	find(is_conc,0,nonconc);
	if(nonconc.get_size()==1 && sum < natom) from_same=true;
      }
      //fill in the rest of atomic species w/o constraint randomly out of those species that are not constrain 	
        int free_site;
        for (int i=0; i<global_eligible.get_size(); i++){
            free_site = global_eligible(i);
            find(closest_ind,free_site,gind);
	    occup = random (gind.get_size());

             for (int k = 0; k<gind.get_size(); k++){
    	     	if (k == occup){
                 	if (vac_type == -1){
				if(from_same){
					species = random (super_site_type_list(free_site).get_size());
				}else{
					do{
                  				species = random (super_site_type_list(free_site).get_size());
					}while(is_conc(super_site_type_list(free_site)(species))==1);
				}
                  	}else{
    	      			if(from_same){
					do{
                     				species = random (super_site_type_list(free_site).get_size());
    	        			}while(super_site_type_list(free_site)(species) == vac_type);
				}else{
					do{
                     				species = random (super_site_type_list(free_site).get_size());
    	        			}while(super_site_type_list(free_site)(species) == vac_type || is_conc(super_site_type_list(free_site)(species))==1);
    	      			}
			}
                    	outfile<<iaxes*str.super_site_pos(gind(k))<<" "<<atom_label(super_site_type_list(free_site)(species))<<endl;
    	     	}else{
                    if (printVac) outfile<<iaxes*str.super_site_pos(gind(k))<<" Vac"<<endl;
                } 
             }
	}
   }//finish if there is constriant
   
   return 0;

}
