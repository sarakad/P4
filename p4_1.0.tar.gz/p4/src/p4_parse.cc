//This file is part of the P4 package
#include "p4_parse.hh"

void read_force(Array<Real> *pforce, istream &file, const Array<int> &copyfrom) {
  Array<rVector3d> force(copyfrom.get_size());
  for (int at=0; at<copyfrom.get_size(); at++) {
    file >> force(at);
  }
  pforce->resize(3*force.get_size());
  for (int at=0; at<copyfrom.get_size(); at++) {
    for (int i=0; i<3; i++) {
      (*pforce)(3*at+i)=force(copyfrom(at))(i);
    }
  }
}
void read_eigval(Array<Real> &eigval, istream &file, const Array<int> &copyfrom) {
  Array<Real> val(copyfrom.get_size()*3);
  string val2;
  for (int i=0; i<3*copyfrom.get_size(); i++){
  	file >> val(i);
  }
  eigval.resize(val.get_size());
  for (int at=0; at<copyfrom.get_size(); at++) {
      for (int i=0;i<3;i++){
      	  eigval(3*at+i)=-val(3*copyfrom(at)+i);
      }
  }
}
void read_eigvec(Array2d<Real> &eigvec, istream &file, const Array<int> &copyfrom){


  Array2d<Real> val(copyfrom.get_size()*3,copyfrom.get_size()*3);
  
  for (int i=0; i<3*copyfrom.get_size(); i++){
      for (int j=0; j<3*copyfrom.get_size(); j++){
      		file >> val(j,i);
      }
  }
  eigvec.resize(copyfrom.get_size()*3,copyfrom.get_size()*3);
  for (int at1=0; at1<copyfrom.get_size(); at1++) {
      for (int i1=0;i1<3;i1++){
           for (int at2=0; at2<copyfrom.get_size(); at2++){
               for (int i2=0; i2<3; i2++){
			eigvec(3*at1+i1,3*at2+i2)=val(3*copyfrom(at1)+i1,3*copyfrom(at2)+i2);
               }
           }
      }
  }

}
void read_hessian(Array2d<Real> &hess, istream &file, const Array<int> &copyfrom){
  /* note::
       By default VASP prints negative hessian so the elements should be
       multiplied by -1 to restore the original hessian, this is done by
       default, hessian in the XML file is symmetrized by default.
       Hessian in XML file is already divided by the sqrt mass of each dof */

  Array2d<Real> val(copyfrom.get_size()*3,copyfrom.get_size()*3);
  
  for (int i=0; i<3*copyfrom.get_size(); i++){
      for (int j=0; j<3*copyfrom.get_size(); j++){
      		file >> val(i,j);
      }
  }
  
  hess.resize(copyfrom.get_size()*3,copyfrom.get_size()*3);
  for (int at1=0; at1<copyfrom.get_size(); at1++) {
      for (int i1=0;i1<3;i1++){
           for (int at2=0; at2<copyfrom.get_size(); at2++){
               for (int i2=0; i2<3; i2++){
			hess(3*at1+i1,3*at2+i2)=-val(3*copyfrom(at1)+i1,3*copyfrom(at2)+i2);
               }
           }
      }
  }

}
void read_mass(Array<Real> &masses, const char *massfilename, const AugStructure &str, const Array<AutoString> &label) {
  masses.resize(str.atom_type.get_size());
  {
    ifstream massfile;
    Array<Real> atomic_masses;
    if (strlen(massfilename)>0) {
      massfile.open(massfilename);
      if (!massfile) {
        ERRORQUIT("Unable to open atomic masses file");
      }
    }
    else {
      AutoString configfilename(getenv("HOME"));
      configfilename+="/.atat.rc";
      ifstream configfile(configfilename);
      if (!configfile) {
        ERRORQUIT("$HOME/.atat.rc was not found.");
      }
      while (configfile.get()!='=') {};
      skip_delim(configfile," \t");
      AutoString massfilename2;
      get_string(&massfilename2,configfile);
      massfilename2+="/data/masses.in";
      massfile.open(massfilename2);
      if (!massfile) {
	ERRORQUIT("Unable to open atomic masses file");
      }
    }
    read_mass_file(atomic_masses,massfile,label);
    for (int at=0; at<str.atom_type.get_size(); at++) {
      masses(at)=atomic_masses(str.atom_type(at));
    }
  }
}
void read_mass(Array<Real> &masses, const char *massfilename, const Structure &str, const Array<AutoString> &label) {
  masses.resize(str.atom_type.get_size());
  {
    ifstream massfile;
    Array<Real> atomic_masses;
    if (strlen(massfilename)>0) {
      massfile.open(massfilename);
      if (!massfile) {
        ERRORQUIT("Unable to open atomic masses file");
      }
    }
    else {
      AutoString configfilename(getenv("HOME"));
      configfilename+="/.atat.rc";
      ifstream configfile(configfilename);
      if (!configfile) {
        ERRORQUIT("$HOME/.atat.rc was not found.");
      }
      while (configfile.get()!='=') {};
      skip_delim(configfile," \t");
      AutoString massfilename2;
      get_string(&massfilename2,configfile);
      massfilename2+="/data/masses.in";
      massfile.open(massfilename2);
      if (!massfile) {
	ERRORQUIT("Unable to open atomic masses file");
      }
    }
    read_mass_file(atomic_masses,massfile,label);
    for (int at=0; at<str.atom_type.get_size(); at++) {
      masses(at)=atomic_masses(str.atom_type(at));
    }
  }
}
void read_mass_file(Array<Real> &masses, istream &file, const Array<AutoString> &label) {
  masses.resize(label.get_size());
  for (int i=0; i<masses.get_size(); i++) {masses(i)=-1.;}
  while (skip_delim(file)) {
    AutoString curlab;
    get_string(&curlab,file);
    Real m;
    file >> m;
    int i=index_in_array(label,curlab);
    if (i!=-1) {masses(i)=m;}
  }
  for (int i=0; i<masses.get_size(); i++) {
    if (masses(i)==-1.) {
      cerr << "Mass of " << label(i) << " is not known";
      ERRORQUIT("Aborting");
    }
  }
}
void read_quadrature_points(Array<Real> &abscissa, Array<Real> &weights, istream &file){

 unsigned int counter=0;
 LinkedList<Real> abscissa_list;
 LinkedList<Real> weight_list;
 double val1, val2;
 
 while(file>>val1){
 	counter++;	
        abscissa_list << new double ( val1 );
        file>>val2;
        weight_list << new double( val2 );
 }
 abscissa.resize(counter);
 weights.resize(counter); 
 LinkedList_to_Array(&abscissa,abscissa_list);
 LinkedList_to_Array(&weights,weight_list);

}
void read_lattice_file(rMatrix3d *pcell, Array<rVector3d> *patom_pos, Array<int> *psite_type, Array<Arrayint> *psite_type_list, Array<AutoString> *patom_label, istream &file, rMatrix3d *paxes) {
  //this function is the same as parse_lattice_file in parse.c++, with the exception of not removing duplicate lattice site type list
  const char *delim=" \t,;/";
  // read cell;
  rMatrix3d axes;
  read_cell(&axes,file);
  for (int i=0; i<3; i++) {
    rVector3d v;
    file >> v;
    pcell->set_column(i,axes*v);
  }
  if (paxes) {*paxes=axes;}

  // read in atoms;
  LinkedList<rVector3d> atom_pos_list;
  LinkedList<ArrayAutoString> long_site_type_list;
  while (1) {
    rVector3d pos(MAXFLOAT,MAXFLOAT,MAXFLOAT);
    file >> pos;
    if (file.eof() || pos(0)==MAXFLOAT || !file) break;
    pos=axes*pos;
    char buf[MAX_LINE_LEN];
    file.get(buf,MAX_LINE_LEN-1);
    LinkedList<AutoString> site_types;
    char *atom_begin=buf;
    char *string_end=buf+strlen(buf);
    while (atom_begin<string_end) {
      while (strchr(delim,*atom_begin) && atom_begin<string_end) {atom_begin++;}
      if (atom_begin==string_end) break;
      char *atom_end=atom_begin;
      while (!strchr(delim,*atom_end) && atom_begin<string_end) {atom_end++;}
      *atom_end=0;
/*
      LinkedListIterator<AutoString> i(site_types);
      while (i && strcmp(*i,atom_begin)<0) {i++;}
      site_types.add(new AutoString(atom_begin),i);
*/
      site_types << new AutoString(atom_begin);
      atom_begin=atom_end+1;
    }
    Array<AutoString> *parraystring=new Array<AutoString>();
    LinkedList_to_Array(parraystring,site_types);

    LinkedListIterator<ArrayAutoString> i_atom(long_site_type_list);
    LinkedListIterator<rVector3d> i_pos(atom_pos_list);
    while (i_atom && i_atom->get_size() >= parraystring->get_size()) {
      i_atom++;
      i_pos++;
    }
    long_site_type_list.add(parraystring,i_atom);
    atom_pos_list.add(new rVector3d(pos),i_pos);

  }

  // make atom label list;
  LinkedList<AutoString> atom_label_list;
  LinkedListIterator<ArrayAutoString> i_atom(long_site_type_list);
  for (; i_atom; i_atom++) {
    for (int at=0; at<i_atom->get_size(); at++) {
      LinkedListIterator<AutoString> i_label(atom_label_list);
      while (i_label && strcmp(*i_label,(*i_atom)(at))<0) {i_label++;}
      if (!i_label || strcmp(*i_label,(*i_atom)(at))!=0) {
        atom_label_list.add(new AutoString((*i_atom)(at)),i_label);
      }
    }
  }

  // convert string to int in the long site type list;
  LinkedListIterator<ArrayAutoString> il(long_site_type_list);
  LinkedList<Arrayint> long_int_site_type_list;
  for ( ; il; il++) {
    Array<int> *ptype_list=new Array<int>(il->get_size());
    for (int at=0; at<ptype_list->get_size(); at++) {
      LinkedListIterator<AutoString> i_label(atom_label_list);
      int which_type=0;
      while (i_label && strcmp(*i_label,(*il)(at))!=0) {i_label++; which_type++;}
      (*ptype_list)(at)=which_type;
    }
    long_int_site_type_list << ptype_list;
  }

  // create short site type list by removing duplicates;
  LinkedList<Arrayint> short_int_site_type_list;
  LinkedListIterator<Arrayint> ili(long_int_site_type_list);
  for ( ; ili; ili++) {
    LinkedListIterator<Arrayint> is(short_int_site_type_list);
    while (is && (*is)!=(*ili)) {is++;}
    if (!is) {
      short_int_site_type_list << new Array<int>(*ili);
    }
  }


  // convert site type to int;
  LinkedList<int> int_site_type;
  ili.init(long_int_site_type_list);
  for ( ; ili; ili++) {
    LinkedListIterator<Arrayint> is(short_int_site_type_list);
    int which_type=0;
    while ((*is)!=(*ili)) {is++; which_type++;}
    int_site_type << new int(which_type);
  }

  // make arrays from linked lists;
  LinkedList_to_Array(patom_pos,atom_pos_list);
  LinkedList_to_Array(psite_type,int_site_type);
  //LinkedList_to_Array(psite_type_list,short_int_site_type_list);
  LinkedList_to_Array(psite_type_list,long_int_site_type_list); 
  LinkedList_to_Array(patom_label,atom_label_list);
}

void reorder_atoms_notype(Structure *rel_str, const Structure &str, Array<int> *pcopy_from, Array<iVector3d> *pshift) {
  //This function is the same as reorder_atoms in xtalutil.c++ except that it does not check atomic type
  if (rel_str->atom_pos.get_size()!=str.atom_pos.get_size()) {
    ERRORQUIT("Structures of different number of atoms in reorder_atoms!");
  }
  {
    Real scale=pow(det(rel_str->cell)/det(str.cell),1./3.);
    iMatrix3d supercell=to_int((!(rel_str->cell))*(str.cell)*scale);
    rel_str->cell=(rel_str->cell)*to_real(supercell);
  }
  /*
  {
    Real maxr=0;
    for (int i=0; i<3; i++) {maxr=MAX(maxr,norm(str.cell.get_column(i)));}
    Real scale=pow(det(str.cell)/det(rel_str->cell),1./3.);
    maxr*=MAX(1.,pow(scale,-3.));
    Array<rMatrix3d> supercell;
    find_all_equivalent_cell(&supercell,rel_str->cell,maxr);
    Real mind=MAXFLOAT;
    int best_ss;
    for (int s=0; s<supercell.get_size(); s++) {
      Real d=norm(supercell(s)*scale-str.cell);
      if (d<mind) {
	mind=d;
	best_ss=s;
      }
    }
    rel_str->cell=supercell(best_ss);
  }
  */
  int n=str.atom_pos.get_size();
  Array<rVector3d> frac_str,frac_rel_str;
  Array<int> str_done(n),rel_str_done(n);
  zero_array(&str_done);
  zero_array(&rel_str_done);
  rVector3d t(0.,0.,0.);
  apply_symmetry(&frac_str,!str.cell,t,str.atom_pos);
  apply_symmetry(&frac_rel_str,!rel_str->cell,t,rel_str->atom_pos);
  Array<int> copy_from(n);
  Array<iVector3d> shift(n);
  for (int t=0; t<n; t++) {
    Real min_d=MAXFLOAT;
    int best_ir=-1;
    int best_i=-1;
    for (int ir=0; ir<n; ir++) {
      if (rel_str_done(ir)==0) {
        for (int i=0; i<n; i++) {
          if (str_done(i)==0) {
            Real d=cylinder_norm(frac_rel_str(ir)-frac_str(i));
            if (d<min_d) {
              min_d=d;
              best_ir=ir;
              best_i=i;
            }
          }
        }
      }
    }
    /*if (str.atom_type(best_i)!=rel_str->atom_type(best_ir)) {
      ERRORQUIT("Too large shift between relaxed and unrelaxed positions.");
    }*/
    copy_from(best_i)=best_ir;
    rVector3d s=frac_str(best_i)-frac_rel_str(best_ir);
    shift(best_i)=to_int(s);
    rel_str_done(best_ir)=1;
    str_done(best_i)=1;
  }
  Structure tmpstr(*rel_str);
  for (int i=0; i<n; i++) {
    rel_str->atom_pos(i)=tmpstr.atom_pos(copy_from(i))+rel_str->cell*to_real(shift(i));
    rel_str->atom_type(i)=tmpstr.atom_type(copy_from(i));
  }
  if (pcopy_from) (*pcopy_from)=copy_from;
  if (pshift) (*pshift)=shift;
}
void read_conc(Array<Real> &conc_list, Array<int> &is_conc, const Array<AutoString> &label, istream &s)
  {
   int vac_type=-1;
   for (int i=0; i<label.get_size(); i++){ 
	if(strcmp(label(i),"Vac")==0 || strcmp(label(i),"Va")==0){
        	vac_type = i;
                break;
        }
   }
  
  int id;
  //Array<Real> conc_list;
  conc_list.resize(label.get_size());
  zero_array(&conc_list);
  //Array<int> is_conc(label.get_size()); 
  is_conc.resize(label.get_size());
  zero_array(&is_conc);
  char * pch;

  for (string line; getline(s, line); ){
     char *line_str = (char*)line.c_str();
     pch = strtok (line_str," =");
     //cout<<pch<<endl;
     if (strcmp(pch,"Vac") !=0 && strcmp(pch,"Va") !=0){
     	for (int ll=0; ll<label.get_size(); ll++){
		if (strcmp(label(ll),pch)==0){ id= ll ; is_conc(ll) = 1;}
     	}
     }else{ ERRORQUIT("Cannot set the value for Vac concentration.");}
     pch = strtok (NULL, " =\n");
     //cout<<pch<<endl;
     conc_list(id) = atof(pch);
  }
  Real sum=0; 

  for (int i=0; i<conc_list.get_size();i++)
	sum +=conc_list(i);

  int nonset=0;
  
  for (int i=0; i<is_conc.get_size();i++){
	if (i != vac_type) {
           if (is_conc(i) == 0) nonset++;
         }
  }
  if (sum>1 && fabs(sum-1)>zero_tolerance)
 	ERRORQUIT("The sum of atomic concentrations provided is larger than 1");
  
  if (nonset == 0 && sum<1)
 	ERRORQUIT("The sum of all atomic concentrations should be 1");
  
  if (nonset == 1){
    for (int i=0; i<is_conc.get_size();i++){
  	if (is_conc(i) == 0 && i != vac_type){
		is_conc(i) = 1;
                conc_list(i) = 1-sum;
                nonset--;
         }
     }
  }
}
