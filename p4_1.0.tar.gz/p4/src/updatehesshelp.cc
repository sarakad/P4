//This file is part of the P4 package
const char *helpstring=""
"Update the hessian matrix based on the quadratic energy surface approximation given the gradient change and displacement\n"
;
