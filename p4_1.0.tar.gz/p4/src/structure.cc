//This file is part of the P4 package
#include "structure.hh"

void AugStructure::init( const char* latticefilename, const char* strfilename  ){
   
  //initialize variable needed for reading the unit cell of the augmented lattice
  rMatrix3d cell;     //unit cell of the lattice
  Array<rVector3d> site_pos; // the positions of all sites in the unit augmented lattice
  Array<int> site_type;
  Array<Arrayint> site_type_list; //possible atomic type on each site
  
  //read augmented lattice file (unit cell in lat.in) 
  ifstream file(latticefilename);
  if (!file) ERRORQUIT("Unable to open lattice file."); 
  parse_lattice_file(&cell, &site_pos, &site_type, &site_type_list, &atom_label, file, &axes);
  if (fabs(det(cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");
  
  file.close();
  wrap_inside_cell(&site_pos,site_pos,cell);
  {
     ofstream labelfile("atoms.out");
     for (int i=0; i<atom_label.get_size(); i++) {
       labelfile << atom_label(i) << endl;
     }
     labelfile.close();
  }
 /* //check the symmetry of lattice cell
  SpaceGroup spacegroup;
  spacegroup.cell=cell;
  find_spacegroup(&spacegroup.point_op,&spacegroup.trans,cell,site_pos,site_type);
  if (contains_pure_translations(spacegroup.point_op,spacegroup.trans)) {
    //if (MyMPIobj.is_root()) cerr << "Warning: unit cell is not primitive." << endl;
   cerr << "Warning: unit cell is not primitive." << endl;
  }
    
   cout<<"in structrue.c++ spacegroup.point_op\n"<<spacegroup.point_op<<endl;
 */ 
  //read structure file 
  ifstream file2(strfilename);
  if (!file2) ERRORQUIT("Unable to open structure file.");
  parse_structure_file(&supercell,&atom_pos,&atom_type,atom_label,file2);
  file2.close();
  if (fabs(det(supercell))<zero_tolerance) ERRORQUIT("Lattice vectors of supercell are coplanar.");
  wrap_inside_cell(&atom_pos,atom_pos,supercell);
  
  //check if the symmetry of the cell for structure is different from lattice and give warning
  if (fabs((det(supercell)/det(cell))-rint(det(supercell)/det(cell)))>0.01)
    ERRORQUIT("The supercell in structure should be an integer multiple of lattice file.");
 
 //create all corresponding sites for the supercell
  //iVector3d simple_supercell;
  //find_common_simple_supercell(&simple_supercell,cell,supercell);
  //rMatrix3d mat_simple_supercell;
  //mat_simple_supercell.diag(to_real(simple_supercell));   
  //cout<<"mat_simple_supercell\n"<<mat_simple_supercell<<endl;

  Array<int> super_site_type;
  find_all_atom_in_supercell(&super_site_pos, &super_site_type, site_pos, site_type, cell, supercell);
  
 // check for vacancies and remove them from atom_pos;
  Array<int> remove_or_not(atom_pos.get_size()); 
  int rem=0 , nbatoms;
  for (int i=0; i<atom_pos.get_size(); i++) {
    if (atom_label(atom_type(i)) == AutoString("Vac")){rem++; remove_or_not(i) = 1;}
    else {remove_or_not(i) = 0;}
  }
  nbatoms = atom_pos.get_size() - rem;
  LinkedList<rVector3d> atom_pos_tmp; 
  LinkedList<int> atom_type_tmp;
  for (int i=0; i<atom_pos.get_size(); i++) {
    if (!remove_or_not(i)) {atom_pos_tmp<<new rVector3d(atom_pos(i)); atom_type_tmp<<new int(atom_type(i));}
  }
  atom_pos.resize(nbatoms);
  atom_type.resize(nbatoms);
  LinkedList_to_Array(&atom_pos,atom_pos_tmp);
  LinkedList_to_Array(&atom_type,atom_type_tmp);
 
  //create the tree-list for query-search
  build_tree(super_site_pos);
  //cout<<"tree->rootptr\t"<<tree->rootptr->pt[0]<<"\t"<<tree->rootptr->pt[1]<<"\t"<<tree->rootptr->pt[2]<<endl;
  //display_tree(tree->rootptr,3);
}
void AugStructure::build_tree(const Array<rVector3d> &super_site_pos)
{
 int num_of_sites = super_site_pos.get_size();
 
 double * r0aug;
 r0aug=(double*) malloc(sizeof(double)*3*super_site_pos.get_size());
 m_copy(super_site_pos,r0aug);
  
 int * index;
 index=(int*) malloc(sizeof(int)*super_site_pos.get_size());
 for (int i=0; i < super_site_pos.get_size(); i++) index[i] = i;

  tree = build_kdtree(r0aug,num_of_sites,3,index,num_of_sites,0);
  if ( tree == NULL){
    free(index);
    free(r0aug);
    ERRORQUIT("Query tree list cannot be built\n");
  }else{
     tree->dims = 3;
     free(index);
     free(r0aug);
  }

}
/*
void set_force(const char* forcefilename, Array<Real> &force)
{
 ifstream forcefile(forcefilename);
 if (!forcefile) {
 cerr << "Unable to open force.out file." << endl;
 ERRORQUIT("Aborting");
 }
 int n = atom_pos.get_size();
 force.resize(n*3);
 zero_array(&force);
 Array<int> copy_from(n);
 read_force(force,forcefile,copy_from);

}
void AugStructure::set_hessian(const char* hessianfilename)
{
 if (!read_str) ERRORQUIT("Read atomic structure before reading hessian file.");
 ifstream hessfile(hessianfilename);
 if (!hessfile) {
 cerr << "Unable to open hessian.out file." << endl;
 ERRORQUIT("Aborting");
 }
 int n = atom_pos.get_size();
 hessian.resize(n*3,n*3);
 Array<int> copy_from(n);
 //read_hessian(&hessian,hessfile,copy_from);

}
*/
void AugStructure::write_str( const char *filename )
{
  ofstream file(filename);
  rMatrix3d iaxes=!(axes);
  write_axes(axes,file,0);
  rMatrix3d frac_cell=iaxes*supercell;
  for (int i=0; i<3; i++) {
    file << frac_cell.get_column(i) << endl;
  }
  for (int i=0; i<atom_pos.get_size(); i++) {
    file << (iaxes*atom_pos(i)) << " " << atom_label(atom_type(i)) << endl;
  }

}
void reorder_atoms_aug(AugStructure *rel_str, const AugStructure &str, Array<int> *pcopy_from, Array<iVector3d> *pshift) {
  if (rel_str->atom_pos.get_size()!=str.atom_pos.get_size()) {
    ERRORQUIT("Structures of different number of atoms in reorder_atoms_aug!");
  }
  {
    Real scale=pow(det(rel_str->supercell)/det(str.supercell),1./3.);
    iMatrix3d supercell=to_int((!(rel_str->supercell))*(str.supercell)*scale);
    rel_str->supercell=(rel_str->supercell)*to_real(supercell);
  }
  /*
  {
    Real maxr=0;
    for (int i=0; i<3; i++) {maxr=MAX(maxr,norm(str.cell.get_column(i)));}
    Real scale=pow(det(str.cell)/det(rel_str->cell),1./3.);
    maxr*=MAX(1.,pow(scale,-3.));
    Array<rMatrix3d> supercell;
    find_all_equivalent_cell(&supercell,rel_str->cell,maxr);
    Real mind=MAXFLOAT;
    int best_ss;
    for (int s=0; s<supercell.get_size(); s++) {
      Real d=norm(supercell(s)*scale-str.cell);
      if (d<mind) {
	mind=d;
	best_ss=s;
      }
    }
    rel_str->cell=supercell(best_ss);
  }
  */
  int n=str.atom_pos.get_size();
  Array<rVector3d> frac_str,frac_rel_str;
  Array<int> str_done(n),rel_str_done(n);
  zero_array(&str_done);
  zero_array(&rel_str_done);
  rVector3d t(0.,0.,0.);
  apply_symmetry(&frac_str,!str.supercell,t,str.atom_pos);
  apply_symmetry(&frac_rel_str,!rel_str->supercell,t,rel_str->atom_pos);
  Array<int> copy_from(n);
  Array<iVector3d> shift(n);
  for (int t=0; t<n; t++) {
    Real min_d=MAXFLOAT;
    int best_ir=-1;
    int best_i=-1;
    for (int ir=0; ir<n; ir++) {
      if (rel_str_done(ir)==0) {
        for (int i=0; i<n; i++) {
          if (str_done(i)==0) {
            Real d=cylinder_norm(frac_rel_str(ir)-frac_str(i));
            if (d<min_d) {
              min_d=d;
              best_ir=ir;
              best_i=i;
            }
          }
        }
      }
    }
    if (str.atom_type(best_i)!=rel_str->atom_type(best_ir)) {
      ERRORQUIT("Too large shift between relaxed and unrelaxed positions.");
    }
    copy_from(best_i)=best_ir;
    rVector3d s=frac_str(best_i)-frac_rel_str(best_ir);
    shift(best_i)=to_int(s);
    rel_str_done(best_ir)=1;
    str_done(best_i)=1;
  }
  AugStructure tmpstr(*rel_str);
  for (int i=0; i<n; i++) {
    rel_str->atom_pos(i)=tmpstr.atom_pos(copy_from(i))+rel_str->supercell*to_real(shift(i));
    rel_str->atom_type(i)=tmpstr.atom_type(copy_from(i));
  }
  if (pcopy_from) (*pcopy_from)=copy_from;
  if (pshift) (*pshift)=shift;
}
