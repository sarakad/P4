//This file is part of the P4 package
//#include "structure.hh"
#include "version.h"
#include "periodiclib.hh"
#include "p4_parse.hh"
//#include "vclib.hh"

extern Real step_size;
class MotionInVC{
public:
  Array<rVector3d> pos_cur; //current position of minimizer
  Array<rVector3d> pos_next; //next position of minimizer
  Array<Real> force;             //force on minimizer
  
  MotionInVC(void){} 
  MotionInVC(const Array<rVector3d> &_cur_pos) {
     pos_cur=_cur_pos; 
     pos_next=_cur_pos; 
     force.resize(3*pos_cur.get_size()); zero_array(&force);
  }
  MotionInVC(const Array<rVector3d> &_cur_pos,const Array<Real> &_f ) {
     if (3*_cur_pos.get_size() != _f.get_size()) ERRORQUIT("Cannot initialize MotionInVC object due to size mismatch between force and positon of atoms.");
     pos_cur=_cur_pos;
     pos_next=_cur_pos;
     force=_f;
  }
  void perturb_in_vc(const AugStructure &s); 
};
