//This file is part of the P4 package
#include "hessupdatelib.hh"

void update_hessian(Array2d<Real> &hess_new, const Array2d<Real> &hess_old, const Array<Real> &dgrad, const Array<Real> &displacement)
{
	int n = dgrad.get_size();
   	if (displacement.get_size() != n || hess_old.get_size() != iVector2d(n,n))
        	ERRORQUIT("Size mismatch in hessian updating scheme.");
	
        Array<Real> xi(n);
        Array<Real> tmp(n);
	for (int i=0; i<n; i++){
		for (int j=0;j<n;j++){
			tmp(i)+=hess_old(i,j)*displacement(j);
		}
		xi(i)=dgrad(i)-tmp(i);
	}
	
	Array2d<Real> murtagh_correction(n,n), powell_correction(n,n);
	Real phi;
  	murtagh_update(murtagh_correction,xi,dgrad,displacement);
 	powell_update(powell_correction,xi,dgrad,displacement,phi);
	
	for (int i=0; i<n; i++){
		for (int j=0;j<n;j++){
			hess_new(i,j)=(1-phi)*(hess_old(i,j)+murtagh_correction(i,j))+phi*(hess_old(i,j)+powell_correction(i,j));
		}
	}
		

}
void murtagh_update(Array2d<Real> &correction, const Array<Real> &xi, const Array<Real> &dgrad, const Array<Real> &displacement)
{
	int n = dgrad.get_size();
	if (displacement.get_size() != n || xi.get_size() != n)
        	ERRORQUIT("Size mismatch in hessian updating scheme.");
        
        Array2d<Real> tmp2(n,n);
        Real denom=0;
        for (int i=0; i<n; i++){
		for (int j=0;j<n;j++){
	 		tmp2(i,j)=xi(i)*xi(j);
		}
		denom+=displacement(i)*xi(i);
	}

        for (int i=0; i<n; i++){
		for (int j=0;j<n;j++){
	 		correction(i,j)=tmp2(i,j)/denom;
		}
	}

}
void powell_update(Array2d<Real> &correction,const Array<Real> &xi, const Array<Real> &dgrad, const Array<Real> &displacement, Real &phi)
{

	int n = dgrad.get_size();
	if (displacement.get_size() != n || xi.get_size() != n)
        	ERRORQUIT("Size mismatch in hessian updating scheme.");
        
	Real nom=0, denom=0, xinorm=0;
  	Array2d<Real> tmp2(n,n), tmp3(n,n), tmp4(n,n);
        for (int i=0; i<n; i++){
		for (int j=0;j<n;j++){
	 		tmp2(i,j)=displacement(i)*displacement(j);
			tmp3(i,j)=xi(i)*displacement(j);
			tmp4(i,j)=displacement(i)*xi(j);
		}
		denom+=displacement(i)*displacement(i);
		nom+=displacement(i)*xi(i);
		xinorm+=xi(i)*xi(i);
	}
	
        for (int i=0; i<n; i++){
		for (int j=0;j<n;j++){
	 		correction(i,j)=-nom*tmp2(i,j)/(denom*denom)+(tmp3(i,j)+tmp4(i,j))/denom;
		}
	}

	phi = 1 - (nom*nom)/(denom*xinorm);

}
