//This file is part of the P4 package
#include "arraylist.h"
#include "structure.hh"
#include "stringo.hh"
#include "parse.hh"

void read_force(Array<Real> *pforce, istream &file, const Array<int> &copyfrom);
void read_eigval(Array<Real> &eigval, istream &file, const Array<int> &copyfrom);
void read_eigvec(Array2d<Real> &eigvec, istream &file, const Array<int> &copyfrom);
void read_hessian(Array2d<Real> &hess, istream &file, const Array<int> &copyfrom);
void read_mass(Array<Real> &masses, const char *massfilename, const AugStructure &str, const Array<AutoString> &label);
void read_mass(Array<Real> &masses, const char *massfilename, const Structure &str, const Array<AutoString> &label);
void read_mass_file(Array<Real> &masses, istream &file, const Array<AutoString> &label);
void read_quadrature_points(Array<Real> &abscissa, Array<Real> &weights, istream &file);
void read_lattice_file(rMatrix3d *pcell, Array<rVector3d> *patom_pos, Array<int> *psite_type, Array<Arrayint> *psite_type_list, Array<AutoString> *patom_label, istream &file, rMatrix3d *paxes);
void reorder_atoms_notype(Structure *rel_str, const Structure &str, Array<int> *pcopy_from, Array<iVector3d> *pshift);
void read_conc(Array<Real> &conc_list, Array<int> &is_conc, const Array<AutoString> &label, istream &s);
//void write_augstructure(const rMatrix3d &supercell, const Array<rVector3d> &atom_pos, const Array<int> &atom_type, const Array<AutoString> &atom_label, const rMatrix3d &axes, ostream &file, int doabc);
