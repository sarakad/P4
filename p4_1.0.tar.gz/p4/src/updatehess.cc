//This file is part of the P4 package
#include "hessupdatelib.hh"
#include "version.h"
#include "getvalue.h"
#include "p4_parse.hh"
#include "periodiclib.hh"
#include "parse.hh"
#include "integer.h"
#include "xtalutil.h"
extern const char *helpstring;

int main(int argc, char *argv[]) {
  // parse command line arguments or display help (see getvalue.h);
  int dohelp=0;
  const char *latticefilename="lat.in";
  const char *str0filename="str_cur.out";
  const char *str1filename="str_next.out";
  const char *force0filename="force_cur.out";
  const char *force1filename="force_next.out";
  const char *hessfilename="hessian.out";
  const char *hessoutfile="hessian_updated.out";
  int dummy=0;
  

  AskStruct options[]={
    {"","Update the hessian matrix based on the quadratic energy surface approximation given the gradient change and displacement, embedded in ATAT " MAPS_VERSION ", by Sara Kadkhodaei",TITLEVAL,NULL},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-r","Run the command",BOOLVAL,&dummy},
    {"-l","Input file defining the lattice (default: lat.in)",STRINGVAL,&latticefilename},
    {"-s0","Input file defining the current structure (default: str_cur.out)",STRINGVAL,&str0filename},
    {"-s1","Input file defining the updated structure (default: str_next.out)",STRINGVAL,&str1filename},
    {"-f0","Input file defining the current forces (default: force_cur.out)",STRINGVAL,&force0filename},
    {"-f1","Input file defining the updated forces (default: force_next.out)",STRINGVAL,&force0filename},
    {"-h","Input file defining the current hessian (default: hessian.out)",STRINGVAL,&hessfilename},
    {"-oh","Output file defining the updated hessian (default: hessian_updated.out)",STRINGVAL,&hessfilename},
    {"-d","Use all default values",BOOLVAL,&dummy}
  };
  
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }
 // Read the lattice to get atom labels
  Structure lattice;  
  Array<Arrayint> site_type_list; //possible atomic type on each site
  Array<AutoString> atom_label;   //atom label
  rMatrix3d axes;   //coordinate axis
  
  ifstream file(latticefilename);
  if (!file) ERRORQUIT("Unable to open lattice file."); 
    read_lattice_file(&lattice.cell, &lattice.atom_pos, &lattice.atom_type, &site_type_list, &atom_label, file, &axes);

  if (fabs(det(lattice.cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");
  file.close();
   
 // Read structures and reorder
  Structure str0, str1;
  
  file.open(str0filename);
  if (!file) ERRORQUIT("Unable to open current structure file."); 
  parse_structure_file(&str0.cell, &str0.atom_pos, &str0.atom_type, atom_label, file, &axes);
  file.close();

  if (fabs(det(str0.cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");
 
  file.open(str1filename);  
  if (!file) ERRORQUIT("Unable to open updated structure file."); 
  parse_structure_file(&str1.cell, &str1.atom_pos, &str1.atom_type, atom_label, file, &axes);
  file.close();

  if (fabs(det(str1.cell))<zero_tolerance) ERRORQUIT("Lattice vectors are coplanar.");

  if (str0.atom_type.get_size() != str1.atom_type.get_size())
	ERRORQUIT("Number of atoms are not equal in current and updated structures.");

  if (norm(str0.cell - str1.cell)>zero_tolerance)
	ERRORQUIT("The cell shape and volume is not identical in current and updated structures."); 
  
  int natom = str0.atom_type.get_size();
  Array<int> copy;
  Array<iVector3d> cellshift;
  cout<<"str0 before reorder\n"<<str0.atom_pos<<endl;
  cout<<"str1 before reorder\n"<<str1.atom_pos<<endl;


  reorder_atoms(&str1, str0, &copy, &cellshift);
  cout<<"copy\n"<<copy<<endl;
  cout<<"str0 after reorder\n"<<str0.atom_pos<<endl;
  cout<<"str1 after reorder\n"<<str1.atom_pos<<endl;
  //Calculate the periodic distance
  Array<rVector3d> disp(natom);
  Array<Real> dr(3*natom);
  periodic_distance(str1.atom_pos,str0.atom_pos,str0.cell,disp);
  for (int i=0; i<natom; i++){
	for (int j=0; j<3; j++){
		dr(3*i+j)=disp(i)(j);
	}
  }
  //Read the hesisan file and multiply in mass and negative value 
  Array<int> copy_orig(natom);
  for (int i=0; i<natom; i++) copy_orig(i)=i;
  Array2d<Real> hess;
  ifstream hessfile("hessian.out"); 
  if(!hessfile) ERRORQUIT("Unable to open hessian file");
  read_hessian(hess,hessfile,copy_orig);
  hessfile.close();
  
  Array<Real> masses(natom); 
  read_mass(masses, "", str0, atom_label);
  for (int at1=0; at1<natom; at1++) {
      for (int i1=0;i1<3;i1++){
           for (int at2=0; at2<natom; at2++){
               for (int i2=0; i2<3; i2++){
			hess(3*at1+i1,3*at2+i2)*=-sqrt(masses(at1)*masses(at2));
               }
           }
      }
  }
  
  //Read the forces and calculated the gradient difference
 
  Array<Real> force0, force1;
  ifstream forcefile("force_cur.out");
  if(!forcefile) ERRORQUIT("Unable to open force file");
  read_force(&force0,forcefile,copy_orig); 
  forcefile.close();
  forcefile.open("force_next.out");
  if(!forcefile) ERRORQUIT("Unable to open force file");
  read_force(&force1,forcefile,copy); 
  forcefile.close();
 
  Array<Real> dg(3*natom);
  for (int i=0; i<natom*3; i++){
		dg(i)=-(force1(i)-force0(i)); // the force is the negative gradient
  }

  //update the hessian
  Array2d<Real> hess_next(3*natom,3*natom);
  update_hessian(hess_next,hess,dg,dr);
 
  for (int at1=0; at1<natom; at1++) {
      for (int i1=0;i1<3;i1++){
           for (int at2=0; at2<natom; at2++){
               for (int i2=0; i2<3; i2++){
			hess_next(3*at1+i1,3*at2+i2)/=-sqrt(masses(at1)*masses(at2));
               }
           }
      }
  }
  
  ofstream outfile(hessoutfile);
  for (int at1=0; at1<natom; at1++) {
      for (int i1=0;i1<3;i1++){
           for (int at2=0; at2<natom; at2++){
               for (int i2=0; i2<3; i2++){
			outfile<<hess_next(3*copy(at1)+i1,3*copy(at2)+i2)<<"\t";
               }
           }
           outfile<<endl;
      }
  }
  cout<<"Hessian is updated.\n";

  return 0;
}
