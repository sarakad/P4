//This file is part of the P4 package
#include "mcmc.hh"
#include "hessupdatelib.hh"
#include <sys/stat.h>
#define DEBUG

Real step_size=0.01;
unsigned int maxiter=1*pow(10.0,9);
unsigned int burnIn_steps=10000;
unsigned int gap_steps=10000; //addd a statistical analysis function to suggest the best gap_steps
unsigned int trial_steps=500*gap_steps;
Real etol=0.001;

Real curve_val=20;
Real kb=8.6173324*pow(10,-5);//Boltzman constant in ev/K
Real h=4.135667516*pow(10,-15); //ev.s

ofstream mcmclog("mcmc.log");

void MCMC::perturb(void)
{
    Array<rVector3d> dr(pos_cur.get_size());
 
    for (int i=0; i<pos_cur.get_size(); i++){
         dr(i)=rVector3d(2*uniform01()-1,2*uniform01()-1,2*uniform01()-1)*step_size; 
         pos_next(i)=pos_cur(i)+dr(i);
    }
    wrap_inside_cell(&pos_next,pos_next,cell);
}
int MCMC::accept()
{
 int acc=0;
 Real a,A;
 Real beta=1/kb/T;
 a=exp(-beta*(e_next-e_cur));
 A=uniform01();
 
 if(A<a) acc=1; 

 return acc;
}
void MCMC::print_status(void)
{
   
    mcmclog<<"The parameters for Monte Carlo sampling\n"; 
    mcmclog<< "\tTemperature for the canonical sampling is\t"<<T<<endl;
    mcmclog<< "\tMaximum step size\t"<<step_size<<endl;
    mcmclog<< "\tNumber of burnIn steps is\t" <<burnIn_steps<< endl;
    mcmclog<< "\tNumber of gap between steps is\t" <<gap_steps<< endl;
    mcmclog<<endl;
}
void MCMCHarmonic::init(const char* forcefilename, const char* hessfilename, const Array<rVector3d> &rel_pos, const Array<rVector3d> &init_pos, const Array<Real> &masses, const Real _lambda)
{
  int n = rel_pos.get_size();
  if (init_pos.get_size() != n || masses.get_size() != n) 
		ERRORQUIT("Size mismatch in initialization of MCMCHarmonic");
  
  pos0_real.resize(n); 
  pos0_real = rel_pos;
  pos0_ref.resize(n);
  pos0_ref = init_pos;
  
  mass.resize(n); 
  mass = masses;
  
  lambda = _lambda;
  accum = 0;
  accum_count = 0;
  ave_val = 0; 
  c_val = curve_val;  
  
  Array<int> copy(n);
  for (int i=0; i<n; i++) copy(i)=i;

  force.resize(n*3);
  ifstream forcefile(forcefilename);
  if(!forcefile) ERRORQUIT("Unable to open force file");
  read_force(&force,forcefile,copy); 
  forcefile.close();
 
  ifstream hessfile(hessfilename); 
  if(!hessfile) ERRORQUIT("Unable to open hessian file");
  hess.resize(n*3,n*3);
  read_hessian(hess,hessfile,copy);
  hessfile.close();

  e_cur = calc_energy(pos_cur); 
  e_next = calc_energy(pos_next); 

}
Real MCMCHarmonic::calc_energy(const Array<rVector3d> &pos)
{
   
  Real u1,u0;
  u1=calc_energy_harmonic(pos0_real,pos,cell,mass,force,hess);
  u0=calc_energy_harmonic(pos0_ref,pos,cell,c_val);
  
  Real u;
  u=(1-lambda)*u0+lambda*u1;
  return u;

}
void MCMCHarmonic::burnIn()
{
  bool vcell_status=0;
  
  e_cur=calc_energy(pos_cur);	
  for (int i=0; i<burnIn_steps; i++){
        perturb();
        e_next=calc_energy(pos_next);
        vcell_status = is_in_vc(tree,pos_next,pos0_ref,cell);  
        if (accept() && vcell_status){
             pos_cur = pos_next;
             e_cur = e_next;
        }
  }
}
void MCMCHarmonic::run(const unsigned int steps)
{
   Real u1, u0, du;
   bool vcell_status;
   
   //set the energies to current status
   u1=calc_energy_harmonic(pos0_real,pos_cur,cell,mass,force,hess);
   u0=calc_energy_harmonic(pos0_ref,pos_cur,cell,c_val);
   du = u1-u0;
   //int counter = 0;

   for (int kk=0; kk<steps; kk++){
        perturb();
        u1=calc_energy_harmonic(pos0_real,pos_next,cell,mass,force,hess);
        u0=calc_energy_harmonic(pos0_ref,pos_next,cell,c_val);
        e_next=(1-lambda)*u0+lambda*u1;
	vcell_status = is_in_vc(tree,pos_next,pos0_ref,cell);  
        if (accept() && vcell_status){
             pos_cur = pos_next;
             e_cur = e_next;
             du = u1-u0;
        }
        if ( kk % gap_steps == 0 ) {
             accum += du;
             accum_count++;//counter++;
        }  
   }
   
   ave_val = accum/(accum_count);

}
int MCMCHarmonic::estimate_steps(void)
{
   
   unsigned int accepted=0;
   Real du, u1, u0; // du_sum=0;
   LinkedList<Real> du_list;
   bool vcell_status;
   
   //set the energies to current status
   u1=calc_energy_harmonic(pos0_real,pos_cur,cell,mass,force,hess);
   u0=calc_energy_harmonic(pos0_ref,pos_cur,cell,c_val);
   du = u1-u0;
   e_cur = (1-lambda)*u0+lambda*u1;
   
   for (int kk=0; kk<trial_steps; kk++){
        perturb();
        u1=calc_energy_harmonic(pos0_real,pos_next,cell,mass,force,hess);
        u0=calc_energy_harmonic(pos0_ref,pos_next,cell,c_val);
        e_next=(1-lambda)*u0+lambda*u1;
	vcell_status = is_in_vc(tree,pos_next,pos0_ref,cell);  
        if (accept() && vcell_status){
             pos_cur = pos_next;
             e_cur = e_next;
             accepted++;
             du = u1 - u0;
        }
        if ( kk % gap_steps == 0 ) {
             du_list << new double( du );
             accum += du;
             accum_count++;
        }  
   }
   ave_val = (double)accum/accum_count; //(floor(trial_steps/gap_steps)); 
  
   MCStat stat;
   LinkedList_to_Array(&stat.input,du_list);
   
   stat.ave = calc_ave(stat.input);
   stat.variance = calc_variance(stat.input);
   stat.std = calc_std(stat.input);
   stat.sterr = calc_sterr(stat.input);
   stat.view();
 
   double ratioAccepted;
   double real_tol=etol;
   long int target_size;
   ratioAccepted=(double)accepted/trial_steps;
   if (stat.sterr<=etol) { target_size = trial_steps; }
   else{ target_size=(long int)ceil(pow(stat.sterr/etol,2)*trial_steps);}
   if (target_size > maxiter ){
   	target_size = maxiter;
   	real_tol=stat.sterr;
   }
   etol = real_tol;
   
 //  mcmclog << "The accepted number of states:\t" << accepted<<endl;
   mcmclog << "The acceptance ratio for this MC calculation is:\t" << ratioAccepted << endl;
   mcmclog << "Required Monter Carlo steps for an accuracy of " << etol << " is " << target_size <<endl;
   mcmclog << endl;

   return target_size;
}
void MCMCHarmonic::test(void)
{
   int steps = pow(10,6);
   unsigned int accepted=0;
   Real du, u1, u0;
   Array<Real> du_arr(steps);
   bool vcell_status;
   
   ofstream file("burnIn.txt");	
   file<<"#step #val\n";
 
   ofstream filep("gap.txt");	
   filep<<"#block #decay\n";
   
   //set the energies to current status
   u1=calc_energy_harmonic(pos0_real,pos_cur,cell,mass,force,hess);
   u0=calc_energy_harmonic(pos0_ref,pos_cur,cell,c_val);
   du = u1-u0;
   e_cur = (1-lambda)*u0+lambda*u1;
   
   for (int kk=0; kk<steps; kk++){
        perturb();
        u1=calc_energy_harmonic(pos0_real,pos_next,cell,mass,force,hess);
        u0=calc_energy_harmonic(pos0_ref,pos_next,cell,c_val);
        e_next=(1-lambda)*u0+lambda*u1;
	vcell_status = is_in_vc(tree,pos_next,pos0_ref,cell);  
        if (accept() && vcell_status){
             pos_cur = pos_next;
             e_cur = e_next;
             accepted++;
             du = u1 - u0;
        }
        du_arr(kk) = du;
        if (kk < 50000) file<<kk<<"\t"<<du<<endl;
   }
  
   MCStat stat;
   Array<Real> tmp;
   Array<Real> ave_b;
   LinkedList<Real> p_val_list;
   Real p;
   int bi=99, bf=floor(steps/10), delta=100, nb;
   for (int i=bi; i<bf; i+=delta){
        nb = du_arr.get_size()/(i+1);
        ave_b.resize(nb);
        stat.input.resize(i+1);
        for (int j=0; j<nb; j++){
		for (int k=0; k<(i+1); k++) stat.input(k)=du_arr(j*(i+1)+k);  
		ave_b(j)=calc_ave(stat.input);
        }
	p = (i+1)*calc_variance(ave_b)/calc_variance(du_arr);
        filep<<(i+1)<<"\t"<<p<<endl;
	p_val_list << new Real(p); 
    }
   Array<int> pval;
   LinkedList_to_Array(&pval,p_val_list);

   file.close();
   filep.close();
}
void MCMCRef::init(const Array<rVector3d> &init_pos)
{
  int n = init_pos.get_size();
  
  pos0_ref.resize(n);
  pos0_ref = init_pos;
  
  accum = 0;
  accum_count = 0;
  ave_val = 0; 
  c_val = curve_val;  

  e_cur = calc_energy(pos_cur); 
  e_next = calc_energy(pos_next); 

}
Real MCMCRef::calc_energy(const Array<rVector3d> &pos)
{
   
  Real u0;
  u0=calc_energy_harmonic(pos0_ref,pos,cell,c_val);
  
  return u0;

}
void MCMCRef::burnIn()
{
  for (int i=0; i<burnIn_steps; i++){
        perturb();
        e_next=calc_energy(pos_next);
        if (accept()){
             pos_cur = pos_next;
             e_cur = e_next;
        }
  }
}
void MCMCRef::run(const unsigned int steps)
{
   bool vcell_status;
   
   //set the energies to current status
   e_cur=calc_energy_harmonic(pos0_ref,pos_cur,cell,c_val);

   for (int kk=0; kk<steps; kk++){
        perturb();
        e_next=calc_energy_harmonic(pos0_ref,pos_next,cell,c_val);
        if (accept()){
             pos_cur = pos_next;
             e_cur = e_next;
        }
        if ( kk % gap_steps == 0 ) {
                accum_count++;
		vcell_status = is_in_vc(tree,pos_next,pos0_ref,cell);  
		if (vcell_status) accum++;
        }  
   }
   
   ave_val = (double)accum/(accum_count);

}
int MCMCRef::estimate_steps(int ratio_vec_size)
{
   
   unsigned int accepted=0, counter=0;
   double ratioAccepted;
   unsigned int VCS=0; ;
   Array<Real> ratio_vec(ratio_vec_size);
   bool vcell_status;
   
   //set the energies to current status
   e_cur = calc_energy_harmonic(pos0_ref,pos_cur,cell,c_val);
   
  for (int jj=0; jj<ratio_vec_size; jj++){ 
        VCS=0;
        accepted=0;
        counter=0;
        for (int kk=0; kk<trial_steps; kk++){
            perturb();
            e_next=calc_energy_harmonic(pos0_ref,pos_next,cell,c_val);
            if (accept()){
                 pos_cur = pos_next;
                 e_cur = e_next;
                 accepted++;
            }
            if ( kk % gap_steps == 0 ) {
    		vcell_status = is_in_vc(tree,pos_cur,pos0_ref,cell);  
                counter++;
                accum_count++;   
                if(vcell_status){
                	VCS++;
                        accum++;
                }
            }  
       }
       ratio_vec(jj) = (double)VCS/(counter); 
       ratioAccepted=(double)accepted/trial_steps;
       mcmclog<<"Trial number "<<jj<<"\n\tVCS "<<VCS<<"\n\tMC acceptance ratio of "<<ratioAccepted<<"\n\tNumber of states in Voronoi cell to total number of states is "<<ratio_vec(jj)<<endl;
   }   
   ave_val = (double)accum/accum_count; 
   
   MCStat stat;
   stat.input = ratio_vec; 
   stat.ave = calc_ave(stat.input);
   stat.variance = calc_variance(stat.input);
   stat.std = calc_std(stat.input);
   stat.sterr = calc_sterr(stat.input);
   stat.view();
 
   double etol = 1e-3;
   double real_tol=etol;
   long int target_size;
   if (stat.sterr<=etol){ target_size = trial_steps*ratio_vec_size;}
   else{ target_size=(long int)ceil(pow(stat.sterr/etol,2)*trial_steps*ratio_vec_size);}
   if (target_size > maxiter ){
   	target_size = maxiter;
   	real_tol=stat.sterr;
   }
   etol = real_tol;
   
   mcmclog << "Required Monter Carlo steps for an accuracy of " << etol << " is " << target_size <<endl;
   mcmclog << endl;
   
   return target_size;
}
Real calc_energy_harmonic(const Array<rVector3d> &pos0, const Array<rVector3d> &pos, const rMatrix3d cell, const Array<Real> &mass, const Array<Real> &force, const Array2d<Real> &hess)
{
   int n = pos0.get_size();
   if (pos.get_size() != n || mass.get_size() != n || force.get_size() != 3*n || hess.get_size() != iVector2d(3*n,3*n) ) 
        ERRORQUIT("Size mismatch in calc_energy_harmonic.");
   
   Array<rVector3d> dr(n),drm(n);
   periodic_distance(pos,pos0,cell,dr); 
   for (int i=0; i<n; i++) drm(i)=dr(i)*sqrt(mass(i));
   
   Array<Real> drv(3*n);
   Array<Real> drmv(3*n);
   zero_array(&drv); zero_array(&drmv);
   for (int i=0; i<n; i++){
        for (int j=0; j<3;j++){
           drv(3*i+j)=dr(i)(j);
           drmv(3*i+j)=drm(i)(j);
        }
   }
   Array<Real> hdr(3*n);
   zero_array(&hdr);
   for (int k=0; k<3*n; k++){
   	for (int kk=0; kk<3*n; kk++){
        	hdr(k)+=hess(k,kk)*drmv(kk);
        }
   }
   Real e=0;
   for (int i=0; i<3*n; i++) e+=-drv(i)*force(i)+0.5*drmv(i)*hdr(i);  
   
   return e;
}
Real calc_energy_harmonic(const Array<rVector3d> &pos0, const Array<rVector3d> &pos, const rMatrix3d cell, const Array<Real> &mass, const Array<Real> &force, const Array2d<Real> &eigvec, const Array<Real> &eigval)
{
   int n = pos0.get_size();
   if (pos.get_size() != n || mass.get_size() != n || force.get_size() != 3*n || eigval.get_size() != 3*n || eigvec.get_size() != iVector2d(3*n,3*n) ) 
        ERRORQUIT("Size mismatch in calc_energy_harmonic.");
   
   Array<rVector3d> dr(n),drm(n);
   periodic_distance(pos,pos0,cell,dr); 
   for (int i=0; i<n; i++) drm(i)=dr(i)*sqrt(mass(i));
  
   //cout<<"dr\n"<<dr<<endl;
   //cout<<"drm\n"<<drm<<endl; 
   /*Array<Real> drv(3*n);
   Array<Real> drmv(3*n);
   zero_array(&drv); zero_array(&drmv);
   for (int i=0; i<n; i++){
        for (int j=0; j<3;j++){
           drv(3*i+j)=dr(i)(j);
           drmv(3*i+j)=drm(i)(j);
        }
   }
   Array<Real> hdr(3*n);
   zero_array(&hdr);
   for (int k=0; k<3*n; k++){
   	for (int kk=0; kk<3*n; kk++){
        	hdr(k)+=hess(k,kk)*drmv(kk);
        }
   }
   Real e=0;
   for (int i=0; i<3*n; i++) e+=-drv(i)*force(i)+0.5*drmv(i)*hdr(i);  
   */
   Real e=0;
   return e;
}
Real calc_energy_harmonic(const Array<rVector3d> &pos0, const Array<rVector3d> &pos, const rMatrix3d cell, const Real cval)
{
  
   int n = pos0.get_size();
   if (pos.get_size() != n) 
        ERRORQUIT("Size mismatch in calc_energy_harmonic.");
   
   Array<rVector3d> dr(n);
   periodic_distance(pos,pos0,cell,dr); 
  
   Real e=0;
   for (int i=0; i<n; i++){ 
   	for (int j=0; j<3; j++){
        	e+=0.5*dr(i)(j)*cval*dr(i)(j);
        }
   }
   return e;
}
Real f_vib_harmonic(const Array<Real> masses, const Real c_val, const Real T){

 Real q, F=0;
 //Real Q=1; 
 for (int i=0; i< masses.get_size(); i++){
   for (int j=0; j<3; j++){
    q = 2*M_PI*kb*T*sqrt(masses(i)*(1.0364*pow(10,-28))/c_val/pow(h,2));
    //Q *= q;
    F += log(q);
   }
 }
 //cout<<"-kbTlog(Q) = "<<-kb*T*log(Q)<<endl;
 return -kb*T*F;
}
extern const char *helpstring;

int main(int argc, char *argv[]) {
 
  //Initialize MPI object 
  int myrank, numprocs;
  MPI_Init(&argc,&argv);
  MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
  MPI_Comm_rank(MPI_COMM_WORLD,&myrank);

  // parse command line arguments or display help (see getvalue.h);
  int dohelp=0;
  const char *latticefilename="lat.in";
  const char *strfilename="str.in";
  const char *relstrfilename="str_relax.out";
  const char *forcefilename="force_final.out";
  const char *hessfilename="hessian.out";
  int dummy=0;
  int internal=0;
  int seed = 0;
  Real T = 300;
  int gip=0;
  const char *iip ="";
  int integ=0;
  int test=0;
  int do_adiabatic_switching=1;
  int do_ratio_calc=0;
  int do_internal=0;
  Array<Real> abscissa(5);
  abscissa(0)=0.1479; abscissa(1)=0.5521; abscissa(2)=0.7338; abscissa(3)=0.8500; abscissa(4)=0.9662;
  Array<Real> weight(5);
  weight(0)=0.3500; weight(1)=0.3500; weight(2)=0.0833; weight(3)=0.1333;  weight(4)=0.0833;
  Real lambda;

  AskStruct options[]={
    {"","Monte Carlo Markov Chain canonical sampling of the configuration space confined to the Voronoi cell, embedded in ATAT " MAPS_VERSION ", by Sara Kadkhodaei",TITLEVAL,NULL},
    {"-h","Display more help",BOOLVAL,&dohelp},
    {"-gip","Generate Gaussian quadrature points for adiabatic switching thermodynamic integration (default: 5-point Gaussian quadrature)",BOOLVAL,&gip},
    {"-ip","Input file including the Gaussian quadrature points for adiabatic switching thermodynamic integration (a pair of abscissa and weight per line)",STRINGVAL,&iip},
    {"-r","Run Monte Carlo sampling",BOOLVAL,&dummy},
    {"-u","Sample the internal energy of the real system",BOOLVAL,&internal},
    {"-fvib","Calculate vibrational free energy",BOOLVAL,&integ},
    {"-test","Run Monte Carlo sampling to estimate the best parameters for the Markov chain",BOOLVAL,&test},
    {"-T","Temperature in Kelvin (default: 300) ",REALVAL,&T},
    {"-l","Input file defining the augmented lattice (default: lat.in)",STRINGVAL,&latticefilename},
    {"-is","Input file defining the ideal structure (default: str.in)",STRINGVAL,&strfilename},
    {"-rs","Input file defining the relaxed structure (default: str_relax.out)",STRINGVAL,&relstrfilename},
    {"-ff","Input file defining the forces on the relaxed structure (default: force_final.out)",STRINGVAL,&forcefilename},
    {"-hf","Input file defining the hessian of the relaxed structure (default: hessian.out)",STRINGVAL,&hessfilename},
    {"-etol","Target precision for Monte Carlo sampling average calculation (default: 10e-3 eV)",REALVAL,&etol},
    {"-c","Curvature magnitude for the reference state potnetial in adiabatic switching (default: 20 eV/A/A)",REALVAL,&etol},
    {"-sd","Seed for random number generation (default: use clock)",INTVAL,&seed},
    {"-ss","Magnitude for maximum step size in Monte Carlo random sampling (default: 1e-2)",REALVAL,&step_size},
    {"-burnInNum","The number of initial steps in the Markov chain to de discarded (default: 10e4)",INTVAL,&burnIn_steps},
    {"-gapNum","The number of steps in between Markov chain steps to be included in the ensemble averaging (default: 10e4)",INTVAL,&gap_steps},
    {"-ss","Magnitude for maximum step size in Monte Carlo random sampling (default: 1e-2)",REALVAL,&step_size},
    {"-d","Use all default values",BOOLVAL,&dummy}
  };
  
  if (!get_values(argc,argv,countof(options),options)) {
    display_help(countof(options),options);
    return 1;
  }
  if (dohelp) {
    cout << helpstring;
    return 1;
  }
  if (gip){
   if (strlen(iip)!=0){
        cout<<"Reading quadrature points from the file provided by -ip option fot adiabatic switching thermodynamic integration\n";
        ifstream qpfile;  
        qpfile.open(iip);
        if (!qpfile) ERRORQUIT("Unable to open the quadrature point file.\n");  
        read_quadrature_points(abscissa,weight,qpfile);
        qpfile.close();
        if (min(abscissa)< 0 || max(abscissa) >1) ERRORQUIT("Please provide quadrature points in the integration domain [0 1].\n");
     }else{
     	cout<<"Using 5-point Gaussina quadrature for adiabatic switching thermodynamic integration.\n";
     }
     for (int dir=0; dir<abscissa.get_size(); dir++){
  	  ostringstream dirname;
          dirname << "lambda_"<<abscissa(dir)<< '\0';
          cout<<"Creatig directory "<<dirname.str().c_str()<<endl;
          mkdir(dirname.str().c_str(),S_IRWXU | S_IRWXG | S_IRWXO);
          string outstr(dirname.str().c_str()); 
          outstr.append("/lambda");
          ofstream outfile(outstr.c_str());
          outfile<<abscissa(dir);
          outfile.close();
          string outstr2(dirname.str().c_str()); 
          outstr2.append("/weight");
          ofstream outfile2(outstr2.c_str());
          outfile2<<weight(dir);
	  outfile2.close();
     }
     ostringstream dirname2;
     dirname2 << "ratio_ref"<<'\0';
     cout<<"Creatig directory "<<dirname2.str().c_str()<<endl;
     mkdir(dirname2.str().c_str(),S_IRWXU | S_IRWXG | S_IRWXO);
     string outstr3(dirname2.str().c_str()); 
     outstr3.append("/ratio");
     ofstream outfile3(outstr3.c_str());
     return 1;
  } 

  if (integ){
      Real de, integral=0;
      for (int ii=0; ii<weight.get_size(); ii++){
  	  ostringstream inname;
          inname<<"./lambda_"<<abscissa(ii)<<"/denergy";
          ifstream infile(inname.str().c_str());
          if (!infile || (infile.peek() == infile.eof())){
               string errmessage = "No denergy value could be read in ";
               errmessage.append(inname.str().c_str());	
               ERRORQUIT(errmessage.c_str()); 
          }
          infile >> de;
          integral += de * weight(ii);
      }
     //read str.in as the initial position of atoms 
     AugStructure str_ref; 
     str_ref.init(latticefilename,strfilename);
     //read in the masses for atoms 
     Array<Real> masses_ref(str_ref.atom_pos.get_size()); 
     read_mass(masses_ref, "", str_ref, str_ref.atom_label);
     

     Real ratio; 
     ifstream infile2("./ratio_ref/ratio");
     if (!infile2 || (infile2.peek() == infile2.eof())){
          ERRORQUIT("No ratio value can be read in ./ratio_ref"); 
     }
     infile2 >> ratio;
   
     Real en_rel;
     ifstream infile3("./energy_relax");
     if (!infile3 || (infile3.peek() == infile3.eof())){
          ERRORQUIT("No energy value can be read in ./energy_relax"); 
     }
     infile3 >>en_rel ;
     ofstream final("fvib"); 
     Real final_f = 0;
     final_f = en_rel - kb*T*log(ratio) + f_vib_harmonic(masses_ref,curve_val,T) + integral;  
     final << T<<"\t"<<final_f<<endl; 
     return 1;
  }
   
  MPI_Barrier(MPI_COMM_WORLD);
  //----------------------------------do mcmc performance
  ifstream lam_file("lambda");
  ifstream wei_file("weight");
  ifstream ratio_file("ratio");
  if (!ratio_file){
  	do_ratio_calc=0;
        if(!internal){
  	        do_internal=0;
  		if (!lam_file || !wei_file ){
  			do_adiabatic_switching=0;
        		ERRORQUIT("Please provide both lambda and weight files. You can use \"mcmc -gip\" option.\n");
  		}else{
                	do_adiabatic_switching=1;
     			lam_file >> lambda;
  		}
        }
  }else{
  	do_ratio_calc=1;
        do_adiabatic_switching=0;
	do_internal=0;
        if(internal) cout<<"Doing ratio calculation for reference system. Ignoring the -u option.";
        lambda = 0; //set lambda=0 for test option
  }
  
  ifstream energyfile("./energy_relax");
  if (internal){
	do_ratio_calc=0;
	do_adiabatic_switching=0;
        do_internal =1;
        if (!energyfile) ERRORQUIT("Please provide energy_relax file.");
	lambda = 1; //set lambda=1 for test option
  }
  
  //zero_tolerance = 0.01 * step_size;

  //set the lattice, structure, force and hessian file to the upper directory
  string up_lat("../");
  up_lat.append(latticefilename);
 
  string up_str("../");
  up_str.append(strfilename);

  string up_relstr("../");
  up_relstr.append(relstrfilename);
  
  string up_force("../");
  up_force.append(forcefilename);
  
  string up_hess("../");
  up_hess.append(hessfilename);
  
  

  AugStructure str0, rel_str;
  if(!internal){
  	//read str.in as the initial position of atoms 
  	str0.init(up_lat.c_str(),up_str.c_str());
  	//read str_relax.out as the relaxed geometry of the atoms 
  	rel_str.init(up_lat.c_str(),up_relstr.c_str());
  }else{
  	//read str.in as the initial position of atoms 
  	str0.init(latticefilename,strfilename);
  	//read str_relax.out as the relaxed geometry of the atoms 
  	rel_str.init(latticefilename,relstrfilename);
  }
  //reorder atoms in their initial position to match the order in the relaxed position 
  Array<int> copy_from;
  Array<iVector3d> cellshift;
  reorder_atoms_aug(&str0,rel_str,&copy_from,&cellshift);
 
   //read atom numbers and check compatibility of str files 
  int natom = rel_str.atom_pos.get_size();
  
  if (str0.atom_pos.get_size() != natom) ERRORQUIT("The number of atoms in str.in and str_relax.out are not the same.");
  if (norm(str0.supercell  - rel_str.supercell)>zero_tolerance) ERRORQUIT("Cell shape for the initial and relaxed structures are different.");; 
  
  //check if the currect atomic position is inside the Voronoi cell
  if(!is_in_vc(str0.tree,rel_str.atom_pos,str0.atom_pos,str0.supercell)) {
     cerr<<"Note: You are getting the following error most likely becuase the initial atomic position in str.in are not exactly the same as the lattice site positions inside lat.in\n"; 
     ERRORQUIT("The strutrure is not initially inside the Voronoi cell.");
  }
  
  MPI_Barrier(MPI_COMM_WORLD);

  if (test){
       ofstream mcmctest("mcmc_test.log");
       mcmctest<<"Performing test run to estimate the most efficient parameters for MCMC.\n"; 
    
       //read in the masses for atoms 
       Array<Real> masses(natom); 
       read_mass(masses, "", rel_str, rel_str.atom_label);
       //etol = etol * natom;
    
       rndseed(seed);
      
       if (myrank == 0){
       	MCMCHarmonic mcmch(str0.atom_pos,str0.supercell,T);
       	if (!internal){//read upper directory for force and hessian
        	mcmch.init(up_force.c_str(),up_hess.c_str(),rel_str.atom_pos,str0.atom_pos,masses,lambda); 
       	}else{ //read the current directory
        	mcmch.init(forcefilename,hessfilename,rel_str.atom_pos,str0.atom_pos,masses,1); 
        }
        mcmch.init_tree(str0.tree);
       	mcmch.test();
       }
       MPI_Barrier(MPI_COMM_WORLD); 
       mcmctest<<"Plot the files gap.txt and burnIn.txt to determine the best numeber of gap steps and burnIn period, respcetively\n";
       mcmctest<<"\t burnIn.txt indicates step number vs. value to be averaged. The best burn in steps is the step that the oscillations in the value starts to decay.\n";
       mcmctest<<"\t gap.txt indicates number of steps blocked together vs. decay time. The best gap steps is the number of block steps that the decay time starts to converge.\n";
       return 0;

  }

  if(do_adiabatic_switching){ 
       mcmclog<<"Performing adiabatic switiching for lambda value "<<lambda<<endl;
       
      //read in the masses for atoms 
       Array<Real> masses(natom); 
       read_mass(masses, "", rel_str, rel_str.atom_label);
       //etol = etol * natom;
      
      //--------------- initializing the Markov chain object---------------------------
      
      clock_t begin, end;
      double elapsed_secs;
      begin=clock();
      
      rndseed(seed);
       
      MCMCHarmonic mcmch(str0.atom_pos,str0.supercell,T);
      mcmch.init(up_force.c_str(),up_hess.c_str(),rel_str.atom_pos,str0.atom_pos,masses,lambda); 
      mcmch.init_tree(str0.tree);
      #ifdef DEBUG
      	cout <<"Processor number \t" <<myrank<< "\tcreated MCMCHarmonic object." <<endl; 
      #endif
       
      MPI_Barrier(MPI_COMM_WORLD);
      unsigned long int steps_needed, n; 
      double ave_from_all;
      if (myrank == 0){
      	mcmch.print_status();
        mcmch.burnIn();
      	steps_needed = mcmch.estimate_steps();
        n=(unsigned long int)(steps_needed-trial_steps)/numprocs;
    	mcmclog<< "The number of processors are :\t " << numprocs << endl;
    	mcmclog<< "The trajecory for each process is of length : \t" << n << endl;
    	mcmclog<<endl;
        if (n == 0) ave_from_all = mcmch.ave_val; 
      }
    
      MPI_Barrier(MPI_COMM_WORLD);
      MPI_Bcast(&n, 1, MPI_UNSIGNED_LONG, 0, MPI_COMM_WORLD);
     
      if (n != 0){ 
      	  #ifdef DEBUG
      		cout <<"Processor number \t" <<myrank<< "\tis starting its own trajectory." <<endl; 
     	  #endif
       
          mcmch.burnIn();
          mcmch.run(n);
          
          #ifdef DEBUG
            cout <<"Processor number \t" <<myrank<< "\tis finishing its own trajectory." <<endl; 
          #endif
         
          
          MPI_Barrier(MPI_COMM_WORLD);
          MPI_Reduce(&mcmch.ave_val,&ave_from_all,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
          #ifdef DEBUG
          cout <<"Processor number \t" <<myrank<< "\tave_val and accum are\t"<<mcmch.ave_val<<"\t"<<mcmch.accum<<endl;
          #endif
          
          MPI_Barrier(MPI_COMM_WORLD);
          ave_from_all = ave_from_all /numprocs;
      } 
      if (myrank==0){
      	mcmclog<< "The average energy difference between the reference state and the real energy surface is\t" << ave_from_all <<endl;
            ofstream final_out("denergy");
            final_out<<ave_from_all<<endl;
      }
      if (myrank == 0){
      	end = clock();
      	elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
     	mcmclog<<"The time needed for this calculation is:\t" <<elapsed_secs<<"\tsecs or "<<elapsed_secs/3600<<"\thours\n";
      }
  
  //-----------------------------------------------------------------------------------------------------------
  //do ratio calculation
  }else if (do_ratio_calc){
      mcmclog<<"Performing ratio calculation."<<endl;
      
      clock_t begin, end;
      double elapsed_secs;
      begin=clock();
      
      rndseed(seed);
       
      MCMCRef mcmc(rel_str.atom_pos,rel_str.supercell,T);
      mcmc.init(str0.atom_pos); 
      mcmc.init_tree(str0.tree);
      
      #ifdef DEBUG
      cout <<"Processor number \t" <<myrank<< "\tcreated MCMCRef object." <<endl; 
      #endif
      MPI_Barrier(MPI_COMM_WORLD);
      unsigned long int steps_needed, n; 
      double ave_from_all;
      
      if (myrank == 0){
      	mcmc.print_status();
      	mcmc.burnIn();
      	steps_needed = mcmc.estimate_steps(10);
        n=(unsigned long int)(steps_needed-10*trial_steps)/numprocs;
    	mcmclog<< "The number of processors are :\t " << numprocs << endl;
    	mcmclog<< "The trajecory for each process is of length : \t" << n << endl;
    	mcmclog<<endl;
        if (n == 0) ave_from_all = mcmc.ave_val;
      }
       
      MPI_Barrier(MPI_COMM_WORLD);
      MPI_Bcast(&n, 1, MPI_UNSIGNED_LONG, 0, MPI_COMM_WORLD);
      
      if (n != 0){ 
      	#ifdef DEBUG
      		cout <<"Processor number \t" <<myrank<< "\tis starting its own trajectory." <<endl; 
      	#endif
     
  	mcmc.burnIn();
      	mcmc.run(n);
      
      	#ifdef DEBUG
      	cout <<"Processor number \t" <<myrank<< "\tis finishing its own trajectory." <<endl; 
      	#endif
     
      	MPI_Barrier(MPI_COMM_WORLD);
      	MPI_Reduce(&mcmc.ave_val,&ave_from_all,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
      	#ifdef DEBUG
      		cout <<"Processor number \t" <<myrank<< "\tave_val and accum and accum_count are\t"<<mcmc.ave_val<<"\t"<<mcmc.accum<<"\t"<<mcmc.accum_count<<endl;
      	#endif
      
      	MPI_Barrier(MPI_COMM_WORLD);
      	ave_from_all = (double)ave_from_all/numprocs;
      }
      if (myrank==0){
      	mcmclog<< "The average ratio of state inside Voronoi cell to the total number of sampled states is\t" << ave_from_all <<endl;
        ofstream final_out("ratio");
        final_out<<ave_from_all<<endl;
      	end = clock();
      	elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
     	mcmclog<<"The time needed for this calculation is:\t" <<elapsed_secs<<"\tsecs or "<<elapsed_secs/3600<<"\thours\n";
      }

  }else if(internal){

       mcmclog<<"Performing Monte Carlo Markov chain to obtain the internal energy of the real system\n";
       
      //read in the masses for atoms 
       Array<Real> masses(natom); 
       read_mass(masses, "", rel_str, rel_str.atom_label);
       //etol = etol * natom;
      
      //--------------- initializing the Markov chain object---------------------------
      
      clock_t begin, end;
      double elapsed_secs;
      begin=clock();
      
      rndseed(seed);
       
      MCMCHarmonic mcmch(str0.atom_pos,str0.supercell,T);
      mcmch.init(forcefilename,hessfilename,rel_str.atom_pos,str0.atom_pos,masses,1); 
      mcmch.init_tree(str0.tree);
      #ifdef DEBUG
      	cout <<"Processor number \t" <<myrank<< "\tcreated MCMCHarmonic object." <<endl; 
      #endif
       
      MPI_Barrier(MPI_COMM_WORLD);
      unsigned long int steps_needed, n; 
      double ave_from_all;
      if (myrank == 0){
      	mcmch.print_status();
        mcmch.burnIn();
      	steps_needed = mcmch.estimate_steps();
        n=(unsigned long int)(steps_needed-trial_steps)/numprocs;
    	mcmclog<< "The number of processors are :\t " << numprocs << endl;
    	mcmclog<< "The trajecory for each process is of length : \t" << n << endl;
    	mcmclog<<endl;
        if (n == 0) ave_from_all = mcmch.ave_val; 
      }
    
      MPI_Barrier(MPI_COMM_WORLD);
      MPI_Bcast(&n, 1, MPI_UNSIGNED_LONG, 0, MPI_COMM_WORLD);
     
      if (n != 0){ 
      	  #ifdef DEBUG
      		cout <<"Processor number \t" <<myrank<< "\tis starting its own trajectory." <<endl; 
     	  #endif
       
          mcmch.burnIn();
          mcmch.run(n);
          
          #ifdef DEBUG
            cout <<"Processor number \t" <<myrank<< "\tis finishing its own trajectory." <<endl; 
          #endif
         
          
          MPI_Barrier(MPI_COMM_WORLD);
          MPI_Reduce(&mcmch.ave_val,&ave_from_all,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
          #ifdef DEBUG
          cout <<"Processor number \t" <<myrank<< "\tave_val and accum are\t"<<mcmch.ave_val<<"\t"<<mcmch.accum<<endl;
          #endif
          
          MPI_Barrier(MPI_COMM_WORLD);
          ave_from_all = ave_from_all /numprocs;
      } 
      if (myrank==0){
      	     Real e_min, u_ave;
             energyfile >> e_min; 
             energyfile.close();
             u_ave = e_min + ave_from_all+3*natom/2*kb*T; 
             mcmclog<< "The average internal energy (kinetic and potential) for the real energy surface is\t"<<u_ave<<endl;
            ofstream final_out("ave_u");
            final_out<<u_ave<<endl;
      }
      if (myrank == 0){
      	end = clock();
      	elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
     	mcmclog<<"The time needed for this calculation is:\t" <<elapsed_secs<<"\tsecs or "<<elapsed_secs/3600<<"\thours\n";
      }
  

  }

   
  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();
  return 0; 
}
