//This file is part of the P4 package
#include "kdtree_common.hh"
#include "vectmac.h"
#include "arraylist.h"
#include "integer.h"
#include "parse.h"
#include "vclib.hh"
//#include "p4_parse.hh"

class AugStructure{
public:
  rMatrix3d supercell;   //simulation supercell containing all atoms, i.e. lattice vectors for the supercell
  Array<rVector3d> atom_pos;  //all atom_pos
  Array<int> atom_type; // the atom type of each atom
  Array<rVector3d> super_site_pos;
  Tree *tree;      // a N-D tree list based on the site_pos with N sites in D-dimension
  Array<AutoString> atom_label;   //atom label
  rMatrix3d axes;   //coordinate axis
  //------------constructor and destructor---------//
  
  AugStructure(void){tree = NULL;} 
  AugStructure(const AugStructure &a): supercell(a.supercell), atom_pos(a.atom_pos), atom_type(a.atom_type), super_site_pos(a.super_site_pos),atom_label(a.atom_label), axes(a.axes) {build_tree(super_site_pos);}
  ~AugStructure(){if ( tree ) {free_tree( tree->rootptr ); free(tree);}}
 
  //-------parse structure: read/write---------//
  void init( const char* latticefilename, const char* strfilename ); 
  void write_str( const char *filename);
  /*---------check whether each group of sites is occupied by only one atom----------- */
  /*---------build the tree based on augmented lattice--------------------*/
  void build_tree(const Array<rVector3d> &site_pos);

};

void reorder_atoms_aug(AugStructure *rel_str, const AugStructure &str, Array<int> *pcopy_from, Array<iVector3d> *pshift);
