//This file is part of the P4 package
#include "kdtree_common.hh"
#include "vectmac.h"
#include "arraylist.h"
#include "integer.h"
#include "periodiclib.hh"

int is_in_vc(const Tree* tree, const rVector3d &cur_pos, const rVector3d &init_pos, const rMatrix3d &supercell, rVector3d &normal_vec);
bool is_in_vc(const Tree* tree, const Array<rVector3d> &cur_pos, const Array<rVector3d> &init_pos, const rMatrix3d &supercell, Array<int> &crossif, Array<rVector3d> &normal_vec);
bool is_in_vc(const Tree* tree, const Array<rVector3d> &cur_pos, const Array<rVector3d> &init_pos, const rMatrix3d &supercell);
void find_closestpts(const Tree *tree, const Array<rVector3d> &list, const rMatrix3d &cell, Array<rVector3d> &closest_pts);
void find_closestindx(const Tree *tree, const Array<rVector3d> &list, const rMatrix3d &cell, Array<int> &closest_pts);
void vectorRejection(const rVector3d &f,const rVector3d &nhat1, rVector3d &fv);
void vectorRejection(const rVector3d &f,const rVector3d &nhat1, const rVector3d &nhat2, rVector3d &fv);
void vectorRejection(const rVector3d &f,const rVector3d &nhat1, const rVector3d &nhat2, const rVector3d &nhat3,rVector3d &fv);

//function for copying the array of atom positions to m_format and vice versa to be used in kdtree_common
inline void m_copy(const Array<rVector3d> &r,double * r_copy)
{
int m_size = r.get_size();
for (unsigned int i=0; i< m_size; i++)
	for (unsigned int j=0;j<3;j++)
		r_copy[j*m_size+i]=r[i][j];
        
}
inline void m_copy(const rVector3d &r,double * r_copy)
{

for (unsigned int j=0;j<3;j++)
	r_copy[j]=r[j];
        
}
inline void inv_m_copy(Array<rVector3d> &r,double * r_copy,int m_size)
{
 if (r.get_size() != m_size) ERRORQUIT("Size mismatch in inverse m formatting\n"); 
 for (unsigned int i=0; i< m_size; i++)
                for (unsigned int j=0;j<3;j++)
                        r[i][j]=r_copy[j*m_size+i];
}
inline void inv_m_copy(rVector3d &r,double * r_copy)
{
   for (unsigned int j=0;j<3;j++)
       r[j]=r_copy[j];
}
